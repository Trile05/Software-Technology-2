import tkinter as tk
from tkinter import messagebox
from collections import deque

NODE_WIDTH = 80
NODE_HEIGHT = 40
VERTICAL_GAP = 10
CANVAS_WIDTH = 300
CANVAS_HEIGHT = 500

class QueueVisualizer:
    def __init__(self, root):
        self.root = root
        self.root.title("Queue Visualizer")  # Changed title

        self.stack = deque()  # Changed to deque for queue operations

        self.canvas = tk.Canvas(root, width=CANVAS_WIDTH, height=CANVAS_HEIGHT, bg='white')
        self.canvas.pack(pady=20)

        control_frame = tk.Frame(root)
        control_frame.pack()

        tk.Label(control_frame, text="Enqueue Value:").grid(row=0, column=0)  # Changed label
        self.push_entry = tk.Entry(control_frame, width=10)
        self.push_entry.grid(row=0, column=1)

        push_btn = tk.Button(control_frame, text="Enqueue", command=self.push_value)  # Changed button text
        push_btn.grid(row=0, column=2, padx=5)

        pop_btn = tk.Button(control_frame, text="Dequeue", command=self.pop_value)  # Changed button text
        pop_btn.grid(row=1, column=2, pady=5)

        self.status_label = tk.Label(root, text="", fg="blue", font=("Arial", 12))
        self.status_label.pack(pady=5)

        self.draw_stack()

    def draw_node(self, x, y, data):
        rect = self.canvas.create_rectangle(x, y, x + NODE_WIDTH, y + NODE_HEIGHT, fill="lightblue", outline="black", width=2)
        self.canvas.create_text(x + NODE_WIDTH/2, y + NODE_HEIGHT/2, text=str(data), font=("Arial", 16))
        return rect

    def draw_stack(self):
        self.canvas.delete("all")
        x = (CANVAS_WIDTH - NODE_WIDTH) // 2
        y = CANVAS_HEIGHT - NODE_HEIGHT - 10
        for val in self.stack:  # Removed reversed() to show queue order (front at bottom)
            self.draw_node(x, y, val)
            y -= NODE_HEIGHT + VERTICAL_GAP
        # Draw label for front and back
        if self.stack:
            self.canvas.create_text(x + NODE_WIDTH + 40, CANVAS_HEIGHT - NODE_HEIGHT - 10, text="Front", font=("Arial", 12), fill="red")
            self.canvas.create_text(x + NODE_WIDTH + 40, CANVAS_HEIGHT - NODE_HEIGHT - 10 - (len(self.stack)-1)*(NODE_HEIGHT + VERTICAL_GAP), text="Back", font=("Arial", 12), fill="blue")

    def push_value(self):
        try:
            val = int(self.push_entry.get())
        except ValueError:
            messagebox.showerror("Invalid Input", "Please enter an integer value to enqueue.")
            return
        self.stack.append(val)  # append to back (right side)
        self.push_entry.delete(0, tk.END)
        self.status_label.config(text=f"Enqueued {val} onto queue")  # Changed message
        self.draw_stack()

    def pop_value(self):
        if len(self.stack) == 0:
            messagebox.showinfo("Empty Queue", "Queue is empty. Cannot dequeue.")  # Changed message
            return
        val = self.stack.popleft()  # pop from front (left side)
        self.status_label.config(text=f"Dequeued {val} from queue")  # Changed message
        self.draw_stack()

if __name__ == "__main__":
    root = tk.Tk()
    app = QueueVisualizer(root)

    # Example test cases:
    # app.stack = [10, 20, 30]
    # app.draw_stack()
    root.mainloop()