import tkinter as tk
from tkinter import messagebox

RED = "RED"
BLACK = "BLACK"

class RBNode:
    def __init__(self, key):
        self.key = key
        self.color = RED
        self.left = None
        self.right = None
        self.parent = None

class RedBlackTree:
    def __init__(self):
        self.NIL = RBNode(None)
        self.NIL.color = BLACK
        self.root = self.NIL

    def left_rotate(self, x):
        y = x.right
        x.right = y.left
        if y.left != self.NIL:
            y.left.parent = x
        y.parent = x.parent
        if x.parent is None:
            self.root = y
        elif x == x.parent.left:
            x.parent.left = y
        else:
            x.parent.right = y
        y.left = x
        x.parent = y

    def right_rotate(self, y):
        x = y.left
        y.left = x.right
        if x.right != self.NIL:
            x.right.parent = y
        x.parent = y.parent
        if y.parent is None:
            self.root = x
        elif y == y.parent.right:
            y.parent.right = x
        else:
            y.parent.left = x
        x.right = y
        y.parent = x

    def insert(self, key):
        node = RBNode(key)
        node.left = self.NIL
        node.right = self.NIL
        parent = None
        current = self.root

        while current != self.NIL:
            parent = current
            if key < current.key:
                current = current.left
            else:
                current = current.right

        node.parent = parent

        if parent is None:
            self.root = node
        elif key < parent.key:
            parent.left = node
        else:
            parent.right = node

        node.color = RED
        self.fix_insert(node)

    def fix_insert(self, k):
        while k.parent and k.parent.color == RED:
            if k.parent == k.parent.parent.left:
                u = k.parent.parent.right
                if u.color == RED:
                    k.parent.color = BLACK
                    u.color = BLACK
                    k.parent.parent.color = RED
                    k = k.parent.parent
                else:
                    if k == k.parent.right:
                        k = k.parent
                        self.left_rotate(k)
                    k.parent.color = BLACK
                    k.parent.parent.color = RED
                    self.right_rotate(k.parent.parent)
            else:
                u = k.parent.parent.left
                if u.color == RED:
                    k.parent.color = BLACK
                    u.color = BLACK
                    k.parent.parent.color = RED
                    k = k.parent.parent
                else:
                    if k == k.parent.left:
                        k = k.parent
                        self.right_rotate(k)
                    k.parent.color = BLACK
                    k.parent.parent.color = RED
                    self.left_rotate(k.parent.parent)
        self.root.color = BLACK

    def search(self, node, key):
        if node == self.NIL or key == node.key:
            return node
        if key < node.key:
            return self.search(node.left, key)
        return self.search(node.right, key)

    def inorder(self, node, res=None):
        if res is None:
            res = []
        if node != self.NIL:
            self.inorder(node.left, res)
            res.append((node.key, node.color))
            self.inorder(node.right, res)
        return res

class RBTreeApp:
    def __init__(self, root):
        self.tree = RedBlackTree()
        self.root = root
        self.root.title("Red-Black Tree")

        frame = tk.Frame(root)
        frame.pack(pady=10)

        tk.Label(frame, text="Value:").grid(row=0, column=0)
        self.entry = tk.Entry(frame)
        self.entry.grid(row=0, column=1)

        btn_frame = tk.Frame(root)
        btn_frame.pack()

        tk.Button(btn_frame, text="Insert", command=self.insert).grid(row=0, column=0, padx=5)
        tk.Button(btn_frame, text="Search", command=self.search).grid(row=0, column=1, padx=5)
        tk.Button(btn_frame, text="Show Inorder", command=self.show).grid(row=0, column=2, padx=5)

        self.output = tk.Text(root, height=8, width=50)
        self.output.pack(pady=10)

        self.canvas = tk.Canvas(root, width=800, height=400, bg="white")
        self.canvas.pack()

    def insert(self):
        try:
            value = int(self.entry.get())
        except:
            messagebox.showerror("Error", "Enter integer")
            return
        self.tree.insert(value)
        self.entry.delete(0, tk.END)
        self.draw_tree()

    def search(self):
        try:
            value = int(self.entry.get())
        except:
            messagebox.showerror("Error", "Enter integer")
            return
        node = self.tree.search(self.tree.root, value)
        self.output.delete(1.0, tk.END)
        if node != self.tree.NIL:
            self.output.insert(tk.END, f"Found: {node.key}")
        else:
            self.output.insert(tk.END, "Not found")

    def show(self):
        self.output.delete(1.0, tk.END)
        for k, c in self.tree.inorder(self.tree.root):
            self.output.insert(tk.END, f"{k} ({c})\n")

    def draw_tree(self):
        self.canvas.delete("all")
        if self.tree.root == self.tree.NIL:
            return
        self._draw(self.tree.root, 400, 20, 200)

    def _draw(self, node, x, y, offset):
        if node == self.tree.NIL:
            return

        r = 20

        if node.left != self.tree.NIL:
            self.canvas.create_line(x, y, x - offset, y + 70)
            self._draw(node.left, x - offset, y + 70, offset // 2)

        if node.right != self.tree.NIL:
            self.canvas.create_line(x, y, x + offset, y + 70)
            self._draw(node.right, x + offset, y + 70, offset // 2)

        color = "red" if node.color == RED else "black"
        self.canvas.create_oval(x - r, y - r, x + r, y + r, fill=color)
        self.canvas.create_text(x, y, text=str(node.key), fill="white")

if __name__ == "__main__":
    root = tk.Tk()
    app = RBTreeApp(root)
    root.mainloop()