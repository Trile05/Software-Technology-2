class Graph:

    def __init__(self, directed=False, weighted=False):
        self.graph = {}
        self.weights = {}
        self.directed = directed
        self.weighted = weighted

    def add_vertex(self, vertex):
        if vertex not in self.graph:
            self.graph[vertex] = []

    def add_edge(self, vertex1, vertex2, weight=0):
        if vertex1 in self.graph and vertex2 in self.graph:
            self.graph[vertex1].append(vertex2)

            if self.weighted:
                self.weights[(vertex1, vertex2)] = weight

            if not self.directed:
                self.graph[vertex2].append(vertex1)
                if self.weighted:
                    self.weights[(vertex2, vertex1)] = weight
        else:
            print("One or both vertices not found in graph.")

    def remove_vertex(self, vertex):
        if vertex in self.graph:
            del self.graph[vertex]

            # remove references
            for v in self.graph:
                if vertex in self.graph[v]:
                    self.graph[v].remove(vertex)

    def remove_edge(self, v1, v2):
        if v1 in self.graph and v2 in self.graph[v1]:
            self.graph[v1].remove(v2)

        if not self.directed:
            if v2 in self.graph and v1 in self.graph[v2]:
                self.graph[v2].remove(v1)

    def print_graph(self):
        for v in self.graph:
            print(f"{v} -> {self.graph[v]}")

    def bfs(self, start):
        visited = []
        queue = [start]

        while queue:
            vertex = queue.pop(0)
            if vertex not in visited:
                visited.append(vertex)

                for neighbor in self.graph[vertex]:
                    if neighbor not in visited:
                        queue.append(neighbor)

        return visited

    def dfs(self, start):
        visited = []
        stack = [start]

        while stack:
            vertex = stack.pop()
            if vertex not in visited:
                visited.append(vertex)

                for neighbor in reversed(self.graph[vertex]):
                    if neighbor not in visited:
                        stack.append(neighbor)

        return visited

    def has_undirected_cycle(self):
        visited = set()

        def dfs(v, parent):
            visited.add(v)

            for neighbor in self.graph[v]:
                if neighbor not in visited:
                    if dfs(neighbor, v):
                        return True
                elif neighbor != parent:
                    return True
            return False

        for vertex in self.graph:
            if vertex not in visited:
                if dfs(vertex, None):
                    return True

        return False