import random
import timeit


# RECURSION
# At its core, recursion involves solving a problem 
# by breaking it down into smaller, more manageable instances of the same problem. 

# BASIC RECURSION EXAMPLE
def sum_of_natural_numbers(n):
    if n == 1:
        return 1 # Base case
    else:
        return n + sum_of_natural_numbers(n - 1) # Recursive case
def sum_iterative(n):
    total = 0
    for i in range(1, n+1):
        total += i
    return total
for i in range (5,20,5):
    print(f"The sum of the first {i} natural numbers is {sum_of_natural_numbers(i)}")
    print(f"The sum of the first {i} natural numbers (iterative) is {sum_iterative(i)}")
    sum_time = timeit.timeit(lambda: sum_of_natural_numbers(i), number=10)
    sum_time1 = timeit.timeit(lambda: sum_iterative(i), number=10)
    print(f"The time for normal test:", sum_time)
    print(f"The time for iterative test:", sum_time1)



# RECURSIVELY CALCULATING FIBONACCI SEQUENCE (more difficult example)
# f(n) = f(n - 1) + f(n - 2)
def fibonacci(n):
    if n <= 0:
        return 0 # Base case
    elif n == 1:
        return 1 # Base case 
    else:
        return fibonacci(n - 1) + fibonacci(n - 2) # Recursive case
def fibonacci_iterative(n):
    if n <= 0:
        return 0
    a, b = 0, 1
    for i in range(n-1):
        a, b = b, a + b
    return b
for i in (7,8,9):
    print(f"The {i}th Fibonacci number is {fibonacci(i)}")
    print(f"The {i}th Fibonacci number (iterative) is {fibonacci_iterative(i)}")
    fibonacci_time = timeit.timeit(lambda: fibonacci(i), number=10)
    fibonacci_time1 = timeit.timeit(lambda: fibonacci_iterative(i), number=10)
    print(f"The time for normal test:", fibonacci_time)
    print(f"The time for iterative test:", fibonacci_time1)



# CHALLENGE: Use recursion to calculate the factorial.
def factorial(n):
    if n == 0:
        return 1  # Base case: factorial of 0 is 1
    else:
        return n * factorial(n - 1)  # Recursive case: n! = n * (n-1)!
def factorial_iterative(n):
    result = 1
    for i in range(1, n+1):
        result *= i
    return result

# Example usage:
for i in range (12,15,1):
    print(f"The factorial of {i} is {factorial(i)}")
    print(f"The factorial of {i} (iterative) is {factorial_iterative(i)}")
    factorial_time = timeit.timeit(lambda: factorial(i), number=10)
    factorial_time1 = timeit.timeit(lambda: factorial_iterative(i), number=10)
    print(f"The time for normal test:", factorial_time)
    print(f"The time for iterative test:", factorial_time1)