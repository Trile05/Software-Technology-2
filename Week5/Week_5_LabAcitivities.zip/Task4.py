from tkinter import *
import turtle


class KochSnowflake:
    def __init__(self):
        window = Tk()
        window.title("Koch Snowflake")

        frame1 = Frame(window)
        frame1.pack()

        Label(frame1, text="Enter an order: ").pack(side=LEFT)
        self.order = StringVar()
        self.order.set("0")
        entry = Entry(frame1, textvariable=self.order, justify=RIGHT, width=10)
        entry.pack(side=LEFT)

        Button(frame1, text="Display Koch Snowflake",
               command=self.display).pack(side=LEFT)

        self.canvas = Canvas(window, width=600, height=600)
        self.canvas.pack()

        self.t = turtle.RawTurtle(self.canvas)
        self.t.speed(0)
        self.t.hideturtle()

        window.mainloop()

    def display(self):
        self.t.clear()
        self.t.penup()

        try:
            order = int(self.order.get())
        except ValueError:
            self.t.goto(0, 0)
            self.t.write("Please enter a valid integer",
                         align="center", font=("Arial", 14, "bold"))
            return

        self.t.goto(-200, -150)
        self.t.setheading(60)
        self.t.pendown()

        for _ in range(3):
            self.drawKochCurve(order, 400)
            self.t.right(120)

        self.t.penup()
        self.t.goto(0, 250)
        self.t.write(f"Order {order}", align="center",
                     font=("Arial", 16, "bold"))

    def drawKochCurve(self, order, length):
        if order == 0:  # Base condition
            self.t.forward(length)
        else:
            self.drawKochCurve(order - 1, length / 3)
            self.t.left(60)
            self.drawKochCurve(order - 1, length / 3)
            self.t.right(120)
            self.drawKochCurve(order - 1, length / 3)
            self.t.left(60)
            self.drawKochCurve(order - 1, length / 3)

KochSnowflake()