import unittest
import sys
import os
import pygame

pygame.init()
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from modules.heap import MinHeap


class TestMinHeap(unittest.TestCase):
    def test_insert_and_extract_min(self):
        h = MinHeap()
        values = [5, 3, 8, 1, 9, 2]
        for v in values:
            h.insert(v)

        expected = [1, 2, 3, 5, 8, 9]
        result = []
        while h.get_heap():
            result.append(h.extract_min())
        self.assertEqual(result, expected)

    def test_heap_property_after_insert(self):
        h = MinHeap()
        h.insert(10)
        h.insert(5)
        h.insert(15)
        h.insert(3)
        h.insert(7)
        self.assertEqual(h.get_heap()[0], 3)

    def test_extract_from_empty(self):
        h = MinHeap()
        self.assertIsNone(h.extract_min())

    def test_insert_duplicates(self):
        h = MinHeap()
        h.insert(5)
        h.insert(5)
        h.insert(5)
        h.extract_min()
        self.assertEqual(len(h.get_heap()), 2)


if __name__ == "__main__":
    unittest.main()