import unittest
import sys
import os
import pygame

pygame.init()
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


class TestDP(unittest.TestCase):
    def test_grid_path_obstacles_logic(self):
        ROWS, COLS = 3, 3
        obstacles = {(1, 1)}

        dp = [[0 for _ in range(COLS)] for _ in range(ROWS)]
        for r in range(ROWS):
            for c in range(COLS):
                if (r, c) in obstacles:
                    dp[r][c] = 0
                elif r == 0 and c == 0:
                    dp[r][c] = 1
                else:
                    up = dp[r - 1][c] if r > 0 else 0
                    left = dp[r][c - 1] if c > 0 else 0
                    dp[r][c] = up + left

        self.assertEqual(dp[2][2], 2)

    def test_coin_change_logic(self):
        coins = [1, 5, 10, 25]
        amount = 37
        dp = [float('inf')] * (amount + 1)
        dp[0] = 0

        for i in range(1, amount + 1):
            for coin in coins:
                if i - coin >= 0:
                    dp[i] = min(dp[i], dp[i - coin] + 1)

        self.assertEqual(dp[amount], 4)

    def test_coin_change_amount_zero(self):
        coins = [1, 5, 10, 25]
        amount = 0
        dp = [float('inf')] * (amount + 1)
        dp[0] = 0

        for i in range(1, amount + 1):
            for coin in coins:
                if i - coin >= 0:
                    dp[i] = min(dp[i], dp[i - coin] + 1)

        self.assertEqual(dp[amount], 0)

    def test_coin_change_small_amount(self):
        coins = [1, 5, 10, 25]
        amount = 6
        dp = [float('inf')] * (amount + 1)
        dp[0] = 0

        for i in range(1, amount + 1):
            for coin in coins:
                if i - coin >= 0:
                    dp[i] = min(dp[i], dp[i - coin] + 1)

        self.assertEqual(dp[amount], 2)


if __name__ == "__main__":
    unittest.main()