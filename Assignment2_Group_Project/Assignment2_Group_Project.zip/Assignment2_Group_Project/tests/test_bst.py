import unittest
import sys
import os
import pygame

pygame.init()
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from modules.data_structures import BST


class TestBST(unittest.TestCase):
    def test_insert_and_inorder(self):
        bst = BST()
        values = [50, 30, 70, 20, 40, 60, 80]
        for v in values:
            bst.insert(v)
        self.assertEqual(bst.inorder(), [20, 30, 40, 50, 60, 70, 80])

    def test_preorder(self):
        bst = BST()
        values = [50, 30, 70, 20, 40, 60, 80]
        for v in values:
            bst.insert(v)
        self.assertEqual(bst.preorder(), [50, 30, 20, 40, 70, 60, 80])

    def test_postorder(self):
        bst = BST()
        values = [50, 30, 70, 20, 40, 60, 80]
        for v in values:
            bst.insert(v)
        self.assertEqual(bst.postorder(), [20, 40, 30, 60, 80, 70, 50])

    def test_search(self):
        bst = BST()
        values = [50, 30, 70, 20, 40]
        for v in values:
            bst.insert(v)
        path = bst.search(40)
        self.assertEqual(path, [50, 30, 40])
        path = bst.search(100)
        self.assertEqual(path, [50, 70])

    def test_delete_leaf(self):
        bst = BST()
        bst.insert(50)
        bst.insert(30)
        bst.insert(70)
        bst.delete(30)
        self.assertEqual(bst.inorder(), [50, 70])

    def test_delete_one_child(self):
        bst = BST()
        bst.insert(50)
        bst.insert(30)
        bst.insert(20)
        bst.delete(30)
        self.assertEqual(bst.inorder(), [20, 50])

    def test_delete_two_children(self):
        bst = BST()
        bst.insert(50)
        bst.insert(30)
        bst.insert(70)
        bst.insert(20)
        bst.insert(40)
        bst.insert(60)
        bst.insert(80)
        bst.delete(50)
        self.assertEqual(bst.inorder(), [20, 30, 40, 60, 70, 80])


if __name__ == "__main__":
    unittest.main()