import unittest
import sys
import os
import pygame

pygame.init()
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from modules.data_structures import LinkedList


class TestLinkedList(unittest.TestCase):
    def test_append(self):
        ll = LinkedList()
        ll.append(10)
        ll.append(20)
        ll.append(30)
        self.assertEqual(ll.to_list(), [10, 20, 30])

    def test_insert_at_position(self):
        ll = LinkedList()
        ll.append(10)
        ll.append(30)
        ll.insert_at_position(20, 1)
        self.assertEqual(ll.to_list(), [10, 20, 30])
        ll.insert_at_position(5, 0)
        self.assertEqual(ll.to_list(), [5, 10, 20, 30])

    def test_delete_by_value(self):
        ll = LinkedList()
        ll.append(10)
        ll.append(20)
        ll.append(30)
        ll.delete_by_value(20)
        self.assertEqual(ll.to_list(), [10, 30])
        ll.delete_by_value(10)
        self.assertEqual(ll.to_list(), [30])

    def test_reverse(self):
        ll = LinkedList()
        ll.append(10)
        ll.append(20)
        ll.append(30)
        ll.reverse()
        self.assertEqual(ll.to_list(), [30, 20, 10])

    def test_size(self):
        ll = LinkedList()
        self.assertEqual(ll.size(), 0)
        ll.append(10)
        ll.append(20)
        self.assertEqual(ll.size(), 2)


if __name__ == "__main__":
    unittest.main()