import pygame
import sys

pygame.init()

WIDTH, HEIGHT = 1024, 768
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("DSA Explorer and Visualiser")
FONT_LARGE = pygame.font.SysFont(None, 48)
FONT_MEDIUM = pygame.font.SysFont(None, 32)
FONT_SMALL = pygame.font.SysFont(None, 24)
clock = pygame.time.Clock()

WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
GRAY = (200, 200, 200)
DARK_GRAY = (100, 100, 100)
BLUE = (100, 150, 250)
DARK_BLUE = (50, 100, 200)
GREEN = (100, 200, 100)
RED = (255, 100, 100)
YELLOW = (255, 200, 100)
PURPLE = (200, 100, 255)
ORANGE = (255, 165, 0)


def draw_text(text, font, color, pos, center=False):
    surface = font.render(text, True, color)
    if center:
        rect = surface.get_rect(center=pos)
        screen.blit(surface, rect)
    else:
        screen.blit(surface, pos)


def create_button(screen, text, rect, color, hover_color, is_hovered):
    color = hover_color if is_hovered else color
    pygame.draw.rect(screen, color, rect)
    pygame.draw.rect(screen, BLACK, rect, 3)
    text_surf = FONT_MEDIUM.render(text, True, BLACK)
    text_rect = text_surf.get_rect(center=rect.center)
    screen.blit(text_surf, text_rect)
    return rect


def main_menu():
    button_width = 300
    button_height = 55
    start_y = 120
    spacing = 70

    buttons = {
        "Data Structures": pygame.Rect(WIDTH // 2 - button_width // 2, start_y, button_width, button_height),
        "Sorting Algorithms": pygame.Rect(WIDTH // 2 - button_width // 2, start_y + spacing, button_width,
                                          button_height),
        "Graph Traversal": pygame.Rect(WIDTH // 2 - button_width // 2, start_y + spacing * 2, button_width,
                                       button_height),
        "Heap & Events": pygame.Rect(WIDTH // 2 - button_width // 2, start_y + spacing * 3, button_width,
                                     button_height),
        "Dynamic Programming": pygame.Rect(WIDTH // 2 - button_width // 2, start_y + spacing * 4, button_width,
                                           button_height),
        "Exit": pygame.Rect(WIDTH // 2 - button_width // 2, start_y + spacing * 5, button_width, button_height),
    }

    while True:
        screen.fill(GRAY)
        draw_text("DSA EXPLORER & VISUALISER", FONT_LARGE, DARK_BLUE,
                  (WIDTH // 2, 50), center=True)
        draw_text("Interactive Data Structures and Algorithms Playground",
                  FONT_SMALL, BLACK, (WIDTH // 2, 95), center=True)

        mouse_pos = pygame.mouse.get_pos()

        for name, rect in buttons.items():
            is_hovered = rect.collidepoint(mouse_pos)
            create_button(screen, name, rect, DARK_BLUE, BLUE, is_hovered)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                for name, rect in buttons.items():
                    if rect.collidepoint(event.pos):
                        return name

        pygame.display.flip()
        clock.tick(30)


def run_module(module_name):
    if module_name == "Data Structures":
        from modules.data_structures import run_data_structures_module
        run_data_structures_module(screen, clock)
    elif module_name == "Sorting Algorithms":
        from modules.sorting import run_sorting_module
        run_sorting_module(screen, clock)
    elif module_name == "Graph Traversal":
        from modules.graphs import run_graphs_module
        run_graphs_module(screen, clock)
    elif module_name == "Heap & Events":
        from modules.heap import run_heap_module
        run_heap_module(screen, clock)
    elif module_name == "Dynamic Programming":
        from modules.dp import run_dp_module
        run_dp_module(screen, clock)
    elif module_name == "Exit":
        pygame.quit()
        sys.exit()


def main():
    while True:
        module = main_menu()
        run_module(module)


if __name__ == "__main__":
    main()