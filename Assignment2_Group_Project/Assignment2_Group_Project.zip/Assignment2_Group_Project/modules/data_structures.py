import os

import pygame
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from modules.ui_helpers import draw_button, draw_text, FONT_SMALL, FONT_MEDIUM, WHITE, BLACK, GRAY, BLUE, RED, GREEN, \
    YELLOW, PURPLE, DARK_BLUE




class Stack:
    def __init__(self):
        self._data = []

    def push(self, val):
        self._data.append(val)

    def pop(self):
        if not self.is_empty():
            return self._data.pop()
        raise IndexError("pop from empty stack")

    def peek(self):
        if not self.is_empty():
            return self._data[-1]
        raise IndexError("peek from empty stack")

    def is_empty(self):
        return len(self._data) == 0

    def size(self):
        return len(self._data)

    def get_data(self):
        return self._data.copy()


def stack_visualization(screen, clock):
    stack = Stack()
    counter = 1
    WIDTH, HEIGHT = screen.get_size()
    BLOCK_WIDTH = 200
    BLOCK_HEIGHT = 40
    START_X = (WIDTH - BLOCK_WIDTH) // 2
    BASE_Y = HEIGHT - 120

    instructions = [
        "STACK VISUALIZATION (LIFO)",
        "SPACE: Push | BACKSPACE: Pop | ESC: Return"
    ]

    back_btn = pygame.Rect(20, HEIGHT - 50, 80, 35)

    running = True
    while running:
        screen.fill(GRAY)

        for i, instr in enumerate(instructions):
            text = FONT_SMALL.render(instr, True, BLACK)
            screen.blit(text, (20, 20 + i * 25))

        data = stack.get_data()
        max_display = min(len(data), (BASE_Y - 100) // (BLOCK_HEIGHT + 5))
        visible_data = data[-max_display:] if max_display < len(data) else data

        for i, val in enumerate(visible_data):
            rect = pygame.Rect(START_X, BASE_Y - i * (BLOCK_HEIGHT + 5),
                               BLOCK_WIDTH, BLOCK_HEIGHT)
            pygame.draw.rect(screen, BLUE, rect)
            pygame.draw.rect(screen, BLACK, rect, 2)
            text = FONT_MEDIUM.render(str(val), True, BLACK)
            text_rect = text.get_rect(center=rect.center)
            screen.blit(text, text_rect)

        if stack.is_empty():
            empty_text = FONT_MEDIUM.render("Stack is empty", True, BLACK)
            screen.blit(empty_text, (WIDTH // 2 - 80, HEIGHT // 2))

        pygame.draw.rect(screen, GRAY, back_btn)
        pygame.draw.rect(screen, BLACK, back_btn, 2)
        back_text = FONT_SMALL.render("BACK", True, BLACK)
        screen.blit(back_text, (back_btn.x + 20, back_btn.y + 8))

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE:
                    stack.push(counter)
                    counter += 1
                elif event.key == pygame.K_BACKSPACE:
                    if not stack.is_empty():
                        stack.pop()
                elif event.key == pygame.K_ESCAPE:
                    running = False
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if back_btn.collidepoint(event.pos):
                    running = False

        pygame.display.flip()
        clock.tick(30)


class Queue:
    def __init__(self):
        self._data = []

    def enqueue(self, val):
        self._data.append(val)

    def dequeue(self):
        if not self.is_empty():
            return self._data.pop(0)
        raise IndexError("dequeue from empty queue")

    def is_empty(self):
        return len(self._data) == 0

    def size(self):
        return len(self._data)

    def get_data(self):
        return self._data.copy()


def queue_visualization(screen, clock):
    queue = Queue()
    counter = 1
    WIDTH, HEIGHT = screen.get_size()
    BLOCK_WIDTH = 70
    BLOCK_HEIGHT = 50
    START_X = 80
    Y_POS = HEIGHT // 2 - 25
    MAX_VISIBLE = (WIDTH - 150) // (BLOCK_WIDTH + 10)

    enqueue_btn = pygame.Rect(WIDTH // 2 - 100, HEIGHT - 90, 90, 40)
    dequeue_btn = pygame.Rect(WIDTH // 2 + 10, HEIGHT - 90, 90, 40)
    back_btn = pygame.Rect(20, HEIGHT - 50, 80, 35)

    instructions = [
        "QUEUE VISUALIZATION (FIFO)",
        "ENQUEUE: Add element | DEQUEUE: Remove first | ESC: Return"
    ]

    running = True
    while running:
        screen.fill(GRAY)

        for i, instr in enumerate(instructions):
            text = FONT_SMALL.render(instr, True, BLACK)
            screen.blit(text, (20, 20 + i * 25))

        data = queue.get_data()
        visible_data = data[:MAX_VISIBLE]

        for i, val in enumerate(visible_data):
            rect = pygame.Rect(START_X + i * (BLOCK_WIDTH + 10), Y_POS,
                               BLOCK_WIDTH, BLOCK_HEIGHT)
            pygame.draw.rect(screen, BLUE, rect)
            pygame.draw.rect(screen, BLACK, rect, 2)
            text = FONT_MEDIUM.render(str(val), True, BLACK)
            text_rect = text.get_rect(center=rect.center)
            screen.blit(text, text_rect)

            if i < len(visible_data) - 1:
                start = (rect.right, rect.centery)
                end = (rect.right + 10, rect.centery)
                pygame.draw.line(screen, BLACK, start, end, 2)
                pygame.draw.polygon(screen, BLACK, [
                    (end[0] - 5, end[1] - 3),
                    end,
                    (end[0] - 5, end[1] + 3)
                ])

        if len(data) > MAX_VISIBLE:
            more_text = FONT_SMALL.render(f"... and {len(data) - MAX_VISIBLE} more", True, RED)
            screen.blit(more_text, (START_X + MAX_VISIBLE * (BLOCK_WIDTH + 10), Y_POS + 20))

        mouse_pos = pygame.mouse.get_pos()

        enqueue_color = GREEN if enqueue_btn.collidepoint(mouse_pos) else (100, 200, 100)
        pygame.draw.rect(screen, enqueue_color, enqueue_btn)
        pygame.draw.rect(screen, BLACK, enqueue_btn, 2)
        enq_text = FONT_SMALL.render("ENQUEUE", True, BLACK)
        screen.blit(enq_text, (enqueue_btn.x + 8, enqueue_btn.y + 10))

        dequeue_color = RED if dequeue_btn.collidepoint(mouse_pos) else (255, 150, 150)
        pygame.draw.rect(screen, dequeue_color, dequeue_btn)
        pygame.draw.rect(screen, BLACK, dequeue_btn, 2)
        deq_text = FONT_SMALL.render("DEQUEUE", True, BLACK)
        screen.blit(deq_text, (dequeue_btn.x + 8, dequeue_btn.y + 10))

        pygame.draw.rect(screen, GRAY, back_btn)
        pygame.draw.rect(screen, BLACK, back_btn, 2)
        back_text = FONT_SMALL.render("BACK", True, BLACK)
        screen.blit(back_text, (back_btn.x + 20, back_btn.y + 8))

        if queue.is_empty():
            empty_text = FONT_MEDIUM.render("Queue is empty", True, BLACK)
            screen.blit(empty_text, (WIDTH // 2 - 80, Y_POS + 10))

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if enqueue_btn.collidepoint(event.pos):
                    queue.enqueue(counter)
                    counter += 1
                elif dequeue_btn.collidepoint(event.pos):
                    if not queue.is_empty():
                        queue.dequeue()
                elif back_btn.collidepoint(event.pos):
                    running = False
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    running = False

        pygame.display.flip()
        clock.tick(30)


class ListNode:
    def __init__(self, value):
        self.value = value
        self.next = None


class LinkedList:
    def __init__(self):
        self.head = None

    def append(self, value):
        if not self.head:
            self.head = ListNode(value)
            return
        current = self.head
        while current.next:
            current = current.next
        current.next = ListNode(value)

    def insert_at_position(self, value, position):
        new_node = ListNode(value)
        if position == 0:
            new_node.next = self.head
            self.head = new_node
            return
        current = self.head
        for i in range(position - 1):
            if not current:
                raise IndexError("Position out of range")
            current = current.next
        if not current:
            raise IndexError("Position out of range")
        new_node.next = current.next
        current.next = new_node

    def delete_by_value(self, value):
        current = self.head
        prev = None
        while current:
            if current.value == value:
                if prev:
                    prev.next = current.next
                else:
                    self.head = current.next
                return True
            prev = current
            current = current.next
        return False

    def reverse(self):
        prev = None
        current = self.head
        while current:
            next_node = current.next
            current.next = prev
            prev = current
            current = next_node
        self.head = prev

    def to_list(self):
        elems = []
        current = self.head
        while current:
            elems.append(current.value)
            current = current.next
        return elems

    def size(self):
        count = 0
        current = self.head
        while current:
            count += 1
            current = current.next
        return count


def linked_list_visualization(screen, clock):
    ll = LinkedList()
    WIDTH, HEIGHT = screen.get_size()
    NODE_RADIUS = 25
    START_X = 80
    Y_POS = HEIGHT // 2 - 40
    SPACING = 110
    MAX_NODES = (WIDTH - START_X - 300) // SPACING

    input_text = ""
    input_position = ""
    action = None
    message = ""
    message_timer = 0
    caret_visible = True
    caret_timer = 0
    active_input = None

    append_btn = pygame.Rect(20, HEIGHT - 100, 85, 35)
    insert_btn = pygame.Rect(115, HEIGHT - 100, 85, 35)
    delete_btn = pygame.Rect(210, HEIGHT - 100, 85, 35)
    reverse_btn = pygame.Rect(305, HEIGHT - 100, 85, 35)
    back_btn = pygame.Rect(20, HEIGHT - 50, 80, 35)

    instructions = [
        "LINKED LIST VISUALIZATION",
        "APPEND: Add to end | INSERT: Add at position | DELETE: Remove by value",
        "REVERSE: Reverse the list"
    ]

    def draw_linked_list():
        nodes = ll.to_list()
        display_nodes = nodes[:MAX_NODES]

        for i, val in enumerate(display_nodes):
            x = START_X + i * SPACING
            pygame.draw.circle(screen, BLUE, (x, Y_POS), NODE_RADIUS)
            pygame.draw.circle(screen, BLACK, (x, Y_POS), NODE_RADIUS, 2)
            text = FONT_MEDIUM.render(str(val), True, BLACK)
            text_rect = text.get_rect(center=(x, Y_POS))
            screen.blit(text, text_rect)

            if i < len(display_nodes) - 1:
                start = (x + NODE_RADIUS, Y_POS)
                end = (x + SPACING - NODE_RADIUS, Y_POS)
                pygame.draw.line(screen, BLACK, start, end, 2)
                pygame.draw.polygon(screen, BLACK, [
                    (end[0] - 8, end[1] - 4),
                    end,
                    (end[0] - 8, end[1] + 4)
                ])

        if len(nodes) > MAX_NODES:
            more_text = FONT_SMALL.render(f"... and {len(nodes) - MAX_NODES} more", True, RED)
            screen.blit(more_text, (START_X + MAX_NODES * SPACING, Y_POS - 30))

        if not nodes:
            empty_text = FONT_MEDIUM.render("List is empty", True, BLACK)
            screen.blit(empty_text, (WIDTH // 2 - 60, Y_POS - 12))

    running = True
    while running:
        screen.fill(GRAY)

        for i, instr in enumerate(instructions):
            text = FONT_SMALL.render(instr, True, BLACK)
            screen.blit(text, (20, 20 + i * 22))

        mouse_pos = pygame.mouse.get_pos()

        btn_configs = [
            (append_btn, "APPEND", GREEN),
            (insert_btn, "INSERT", YELLOW),
            (delete_btn, "DELETE", RED),
            (reverse_btn, "REVERSE", PURPLE),
        ]

        for btn, label, color in btn_configs:
            btn_color = color if not btn.collidepoint(mouse_pos) else (min(color[0] + 50, 255), min(color[1] + 50, 255),
                                                                       min(color[2] + 50, 255))
            pygame.draw.rect(screen, btn_color, btn)
            pygame.draw.rect(screen, BLACK, btn, 2)
            btn_text = FONT_SMALL.render(label, True, BLACK)
            screen.blit(btn_text, (btn.x + 10, btn.y + 8))

        pygame.draw.rect(screen, GRAY, back_btn)
        pygame.draw.rect(screen, BLACK, back_btn, 2)
        back_text = FONT_SMALL.render("BACK", True, BLACK)
        screen.blit(back_text, (back_btn.x + 20, back_btn.y + 8))

        if action in ["append", "insert", "delete"]:
            value_label = FONT_SMALL.render("VALUE:", True, BLACK)
            screen.blit(value_label, (WIDTH // 2 + 80, HEIGHT - 85))

            input_rect = pygame.Rect(WIDTH // 2 + 140, HEIGHT - 85, 100, 35)
            pygame.draw.rect(screen, WHITE, input_rect)
            pygame.draw.rect(screen, BLACK, input_rect, 2)

            display_text = input_text
            if active_input == "value" and caret_visible:
                display_text = input_text + "|"
            value_text = FONT_MEDIUM.render(display_text, True, BLACK)
            screen.blit(value_text, (input_rect.x + 5, input_rect.y + 5))

            if action == "insert":
                pos_label = FONT_SMALL.render("POS:", True, BLACK)
                screen.blit(pos_label, (WIDTH // 2 + 260, HEIGHT - 85))

                pos_rect = pygame.Rect(WIDTH // 2 + 300, HEIGHT - 85, 60, 35)
                pygame.draw.rect(screen, WHITE, pos_rect)
                pygame.draw.rect(screen, BLACK, pos_rect, 2)

                display_pos = input_position
                if active_input == "position" and caret_visible:
                    display_pos = input_position + "|"
                pos_text = FONT_MEDIUM.render(display_pos, True, BLACK)
                screen.blit(pos_text, (pos_rect.x + 5, pos_rect.y + 5))

                enter_text = FONT_SMALL.render("Press ENTER to insert", True, DARK_BLUE)
                screen.blit(enter_text, (WIDTH // 2 + 150, HEIGHT - 45))
            else:
                enter_text = FONT_SMALL.render(f"Press ENTER to {action}", True, DARK_BLUE)
                screen.blit(enter_text, (WIDTH // 2 + 170, HEIGHT - 45))

        if message_timer > 0:
            msg_text = FONT_SMALL.render(message, True, RED)
            screen.blit(msg_text, (WIDTH // 2 - 100, HEIGHT - 150))
            message_timer -= 1

        caret_timer += 1
        if caret_timer >= 30:
            caret_timer = 0
            caret_visible = not caret_visible

        draw_linked_list()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if append_btn.collidepoint(event.pos):
                    action = "append"
                    input_text = ""
                    input_position = ""
                    active_input = "value"
                elif insert_btn.collidepoint(event.pos):
                    action = "insert"
                    input_text = ""
                    input_position = ""
                    active_input = "value"
                elif delete_btn.collidepoint(event.pos):
                    action = "delete"
                    input_text = ""
                    input_position = ""
                    active_input = "value"
                elif reverse_btn.collidepoint(event.pos):
                    ll.reverse()
                    message = "List reversed!"
                    message_timer = 60
                elif back_btn.collidepoint(event.pos):
                    running = False
                elif action in ["append", "insert", "delete"]:
                    input_rect = pygame.Rect(WIDTH // 2 + 140, HEIGHT - 85, 100, 35)
                    if input_rect.collidepoint(event.pos):
                        active_input = "value"
                    elif action == "insert":
                        pos_rect = pygame.Rect(WIDTH // 2 + 300, HEIGHT - 85, 60, 35)
                        if pos_rect.collidepoint(event.pos):
                            active_input = "position"
            elif event.type == pygame.KEYDOWN and action:
                if event.key == pygame.K_RETURN:
                    try:
                        if action == "append":
                            if input_text:
                                ll.append(int(input_text))
                                message = f"Appended {input_text}"
                        elif action == "insert":
                            if input_text and input_position:
                                ll.insert_at_position(int(input_text), int(input_position))
                                message = f"Inserted {input_text} at position {input_position}"
                        elif action == "delete":
                            if input_text:
                                if ll.delete_by_value(int(input_text)):
                                    message = f"Deleted {input_text}"
                                else:
                                    message = f"Value {input_text} not found"
                        message_timer = 60
                    except (ValueError, IndexError) as e:
                        message = str(e)
                        message_timer = 60
                    action = None
                    input_text = ""
                    input_position = ""
                    active_input = None
                elif event.key == pygame.K_BACKSPACE:
                    if active_input == "value":
                        input_text = input_text[:-1]
                    elif active_input == "position":
                        input_position = input_position[:-1]
                elif event.key == pygame.K_TAB:
                    if action == "insert":
                        if active_input == "value":
                            active_input = "position"
                        else:
                            active_input = "value"
                elif event.key == pygame.K_ESCAPE:
                    action = None
                    active_input = None
                else:
                    if active_input == "value":
                        if event.unicode.isdigit() or (event.unicode == '-' and not input_text):
                            input_text += event.unicode
                    elif active_input == "position" and action == "insert":
                        if event.unicode.isdigit():
                            input_position += event.unicode

        pygame.display.flip()
        clock.tick(30)

class BSTNode:
    def __init__(self, value):
        self.value = value
        self.left = None
        self.right = None


class BST:
    def __init__(self):
        self.root = None

    def insert(self, value):
        def _insert(node, value):
            if not node:
                return BSTNode(value)
            if value < node.value:
                node.left = _insert(node.left, value)
            elif value > node.value:
                node.right = _insert(node.right, value)
            return node

        self.root = _insert(self.root, value)

    def delete(self, value):
        def _delete(node, value):
            if not node:
                return None
            if value < node.value:
                node.left = _delete(node.left, value)
            elif value > node.value:
                node.right = _delete(node.right, value)
            else:
                if not node.left:
                    return node.right
                if not node.right:
                    return node.left
                min_node = node.right
                while min_node.left:
                    min_node = min_node.left
                node.value = min_node.value
                node.right = _delete(node.right, min_node.value)
            return node

        self.root = _delete(self.root, value)

    def search(self, value):
        path = []
        current = self.root
        while current:
            path.append(current.value)
            if value == current.value:
                return path
            elif value < current.value:
                current = current.left
            else:
                current = current.right
        return path

    def inorder(self):
        result = []

        def _inorder(node):
            if node:
                _inorder(node.left)
                result.append(node.value)
                _inorder(node.right)

        _inorder(self.root)
        return result

    def preorder(self):
        result = []

        def _preorder(node):
            if node:
                result.append(node.value)
                _preorder(node.left)
                _preorder(node.right)

        _preorder(self.root)
        return result

    def postorder(self):
        result = []

        def _postorder(node):
            if node:
                _postorder(node.left)
                _postorder(node.right)
                result.append(node.value)

        _postorder(self.root)
        return result


def draw_bst(screen, node, x, y, x_offset, highlighted=None, search_path=None):
    if not node:
        return x_offset

    if node.left:
        child_x = x - x_offset
        child_y = y + 70
        if child_x > 20 and child_x < screen.get_width() - 20:
            pygame.draw.line(screen, BLACK, (x, y), (child_x, child_y), 2)
        draw_bst(screen, node.left, child_x, child_y, max(20, x_offset // 2), highlighted, search_path)

    if node.right:
        child_x = x + x_offset
        child_y = y + 70
        if child_x > 20 and child_x < screen.get_width() - 20:
            pygame.draw.line(screen, BLACK, (x, y), (child_x, child_y), 2)
        draw_bst(screen, node.right, child_x, child_y, max(20, x_offset // 2), highlighted, search_path)

    color = BLUE
    if highlighted == node.value:
        color = GREEN
    elif search_path and node.value in search_path:
        color = YELLOW

    pygame.draw.circle(screen, color, (x, y), 25)
    pygame.draw.circle(screen, BLACK, (x, y), 25, 2)
    text = FONT_MEDIUM.render(str(node.value), True, BLACK)
    text_rect = text.get_rect(center=(x, y))
    screen.blit(text, text_rect)

    return x_offset


def bst_visualization(screen, clock):
    bst = BST()
    WIDTH, HEIGHT = screen.get_size()
    input_value = ""
    action = None
    search_path = None
    traversal_result = ""
    message = ""
    message_timer = 0
    caret_visible = True
    caret_timer = 0
    active_input = None

    button_y = HEIGHT - 100
    insert_btn = pygame.Rect(20, button_y, 80, 35)
    delete_btn = pygame.Rect(110, button_y, 80, 35)
    search_btn = pygame.Rect(200, button_y, 80, 35)
    inorder_btn = pygame.Rect(300, button_y, 70, 35)
    preorder_btn = pygame.Rect(380, button_y, 70, 35)
    postorder_btn = pygame.Rect(460, button_y, 70, 35)
    back_btn = pygame.Rect(20, HEIGHT - 45, 80, 35)

    instructions = [
        "BINARY SEARCH TREE VISUALIZATION",
        "INSERT: Add value | DELETE: Remove value | SEARCH: Highlight path",
        "IN | PRE | POST: Display traversal orders"
    ]

    running = True
    while running:
        screen.fill(GRAY)

        for i, instr in enumerate(instructions):
            text = FONT_SMALL.render(instr, True, BLACK)
            screen.blit(text, (20, 20 + i * 22))

        mouse_pos = pygame.mouse.get_pos()

        btn_configs = [
            (insert_btn, "INSERT", GREEN),
            (delete_btn, "DELETE", RED),
            (search_btn, "SEARCH", YELLOW),
            (inorder_btn, "IN", BLUE),
            (preorder_btn, "PRE", BLUE),
            (postorder_btn, "POST", BLUE),
        ]

        for btn, label, color in btn_configs:
            btn_color = color if not btn.collidepoint(mouse_pos) else (min(color[0] + 50, 255), min(color[1] + 50, 255),
                                                                       min(color[2] + 50, 255))
            pygame.draw.rect(screen, btn_color, btn)
            pygame.draw.rect(screen, BLACK, btn, 2)
            btn_text = FONT_SMALL.render(label, True, BLACK)
            screen.blit(btn_text, (btn.x + 12, btn.y + 8))

        pygame.draw.rect(screen, GRAY, back_btn)
        pygame.draw.rect(screen, BLACK, back_btn, 2)
        back_text = FONT_SMALL.render("BACK", True, BLACK)
        screen.blit(back_text, (back_btn.x + 20, back_btn.y + 8))

        if action in ["insert", "delete", "search"]:
            value_label = FONT_SMALL.render("VALUE:", True, BLACK)
            screen.blit(value_label, (WIDTH // 2 + 130, HEIGHT - 70))

            input_rect = pygame.Rect(WIDTH // 2 + 190, HEIGHT - 70, 120, 35)
            pygame.draw.rect(screen, WHITE, input_rect)
            pygame.draw.rect(screen, BLACK, input_rect, 2)

            display_text = input_value
            if active_input == "value" and caret_visible:
                display_text = input_value + "|"
            value_text = FONT_MEDIUM.render(display_text, True, BLACK)
            screen.blit(value_text, (input_rect.x + 5, input_rect.y + 5))

            enter_text = FONT_SMALL.render(f"Press ENTER to {action}", True, DARK_BLUE)
            screen.blit(enter_text, (WIDTH // 2 + 160, HEIGHT - 35))

        if traversal_result:
            result_text = FONT_SMALL.render(f"Traversal: {traversal_result}", True, DARK_BLUE)
            screen.blit(result_text, (20, HEIGHT - 160))

        if message_timer > 0:
            msg_text = FONT_SMALL.render(message, True, RED)
            screen.blit(msg_text, (WIDTH // 2 - 100, HEIGHT - 130))
            message_timer -= 1

        caret_timer += 1
        if caret_timer >= 30:
            caret_timer = 0
            caret_visible = not caret_visible

        if bst.root:
            draw_bst(screen, bst.root, WIDTH // 2, 80, 180, None, search_path)
        else:
            empty_text = FONT_MEDIUM.render("Tree is empty", True, BLACK)
            screen.blit(empty_text, (WIDTH // 2 - 70, HEIGHT // 2))

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if insert_btn.collidepoint(event.pos):
                    action = "insert"
                    input_value = ""
                    search_path = None
                    traversal_result = ""
                    active_input = "value"
                elif delete_btn.collidepoint(event.pos):
                    action = "delete"
                    input_value = ""
                    search_path = None
                    traversal_result = ""
                    active_input = "value"
                elif search_btn.collidepoint(event.pos):
                    action = "search"
                    input_value = ""
                    traversal_result = ""
                    active_input = "value"
                elif inorder_btn.collidepoint(event.pos):
                    result = bst.inorder()
                    traversal_result = " -> ".join(str(v) for v in result) if result else "Empty"
                    search_path = None
                elif preorder_btn.collidepoint(event.pos):
                    result = bst.preorder()
                    traversal_result = " -> ".join(str(v) for v in result) if result else "Empty"
                    search_path = None
                elif postorder_btn.collidepoint(event.pos):
                    result = bst.postorder()
                    traversal_result = " -> ".join(str(v) for v in result) if result else "Empty"
                    search_path = None
                elif back_btn.collidepoint(event.pos):
                    running = False
                elif action in ["insert", "delete", "search"]:
                    input_rect = pygame.Rect(WIDTH // 2 + 190, HEIGHT - 70, 120, 35)
                    if input_rect.collidepoint(event.pos):
                        active_input = "value"
            elif event.type == pygame.KEYDOWN and action:
                if event.key == pygame.K_RETURN:
                    if input_value:
                        try:
                            val = int(input_value)
                            if action == "insert":
                                bst.insert(val)
                                message = f"Inserted {val}"
                                search_path = None
                            elif action == "delete":
                                bst.delete(val)
                                message = f"Deleted {val}"
                                search_path = None
                            elif action == "search":
                                search_path = bst.search(val)
                                if search_path and search_path[-1] == val:
                                    message = f"Found {val}"
                                else:
                                    message = f"Value {val} not found"
                            message_timer = 60
                        except ValueError:
                            message = "Invalid input"
                            message_timer = 60
                    action = None
                    input_value = ""
                    active_input = None
                elif event.key == pygame.K_BACKSPACE:
                    if active_input == "value":
                        input_value = input_value[:-1]
                elif event.key == pygame.K_ESCAPE:
                    action = None
                    active_input = None
                else:
                    if active_input == "value":
                        if event.unicode.isdigit() or (event.unicode == '-' and not input_value):
                            input_value += event.unicode

        pygame.display.flip()
        clock.tick(30)


def run_data_structures_module(screen, clock):
    WIDTH, HEIGHT = screen.get_size()

    button_width = 280
    button_height = 50
    start_y = 150
    spacing = 65

    sub_buttons = {
        "Stack": pygame.Rect(WIDTH // 2 - button_width // 2, start_y, button_width, button_height),
        "Queue": pygame.Rect(WIDTH // 2 - button_width // 2, start_y + spacing, button_width, button_height),
        "Linked List": pygame.Rect(WIDTH // 2 - button_width // 2, start_y + spacing * 2, button_width, button_height),
        "Binary Search Tree": pygame.Rect(WIDTH // 2 - button_width // 2, start_y + spacing * 3, button_width,
                                          button_height),
        "Back to Main Menu": pygame.Rect(WIDTH // 2 - button_width // 2, start_y + spacing * 4, button_width,
                                         button_height),
    }

    while True:
        screen.fill(GRAY)
        draw_text(screen, "DATA STRUCTURES PLAYGROUND", FONT_MEDIUM, DARK_BLUE,
                  (WIDTH // 2, 80), center=True)

        mouse_pos = pygame.mouse.get_pos()

        for name, rect in sub_buttons.items():
            is_hovered = rect.collidepoint(mouse_pos)
            color = BLUE if is_hovered else DARK_BLUE
            pygame.draw.rect(screen, color, rect)
            pygame.draw.rect(screen, BLACK, rect, 2)
            text = FONT_MEDIUM.render(name, True, WHITE)
            text_rect = text.get_rect(center=rect.center)
            screen.blit(text, text_rect)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                for name, rect in sub_buttons.items():
                    if rect.collidepoint(event.pos):
                        if name == "Stack":
                            stack_visualization(screen, clock)
                        elif name == "Queue":
                            queue_visualization(screen, clock)
                        elif name == "Linked List":
                            linked_list_visualization(screen, clock)
                        elif name == "Binary Search Tree":
                            bst_visualization(screen, clock)
                        elif name == "Back to Main Menu":
                            return

        pygame.display.flip()
        clock.tick(30)