import pygame
import sys
import random

WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
GRAY = (200, 200, 200)
BLUE = (100, 150, 250)
RED = (255, 100, 100)
GREEN = (100, 200, 100)
YELLOW = (255, 200, 100)
DARK_BLUE = (50, 100, 200)

FONT_SMALL = pygame
FONT_SMALL = pygame.font.SysFont(None, 24)
FONT_MEDIUM = pygame.font.SysFont(None, 32)


def draw_array(screen, array, x, y, width, height, color_positions=None):
    if not array:
        return
    bar_width = width // len(array)
    max_val = max(array) if array else 1

    for i, val in enumerate(array):
        bar_height = (val / max_val) * height
        rect = pygame.Rect(x + i * bar_width, y + height - bar_height, bar_width - 2, bar_height)

        color = BLUE
        if color_positions:
            if i in color_positions.get('compare', []):
                color = YELLOW
            elif i in color_positions.get('swap', []):
                color = RED
            elif i in color_positions.get('sorted', []):
                color = GREEN

        pygame.draw.rect(screen, color, rect)
        pygame.draw.rect(screen, BLACK, rect, 1)


def draw_buttons(screen, buttons, mouse_pos):
    for name, btn in buttons.items():
        color = DARK_BLUE if btn.collidepoint(mouse_pos) else BLUE
        pygame.draw.rect(screen, color, btn)
        pygame.draw.rect(screen, BLACK, btn, 2)
        text = FONT_SMALL.render(name, True, BLACK)
        text_rect = text.get_rect(center=btn.center)
        screen.blit(text, text_rect)


def bubble_sort_step(array, step):
    n = len(array)
    i = step // n
    j = step % n

    if i >= n - 1:
        return array, True, None, None

    if j >= n - i - 1:
        return array, False, None, (i + 1) * 0

    if array[j] > array[j + 1]:
        array[j], array[j + 1] = array[j + 1], array[j]
        return array, False, [j, j + 1], [j, j + 1]

    return array, False, [j, j + 1], None


def selection_sort_step(array, step):
    n = len(array)
    if step >= n - 1:
        return array, True, None, None

    current_min = step
    for j in range(step + 1, n):
        if array[j] < array[current_min]:
            current_min = j

    if current_min != step:
        array[step], array[current_min] = array[current_min], array[step]
        return array, False, [step, current_min], [step, current_min]

    return array, False, None, [step]


def merge_sort_step_by_step(array):
    n = len(array)
    steps = []

    def merge_sort(arr, left, right, steps):
        if left < right:
            mid = (left + right) // 2
            merge_sort(arr, left, mid, steps)
            merge_sort(arr, mid + 1, right, steps)
            merge(arr, left, mid, right, steps)
        return steps

    def merge(arr, left, mid, right, steps):
        left_arr = arr[left:mid + 1]
        right_arr = arr[mid + 1:right + 1]
        i = j = 0
        k = left

        while i < len(left_arr) and j < len(right_arr):
            steps.append(('compare', k, left + i, mid + 1 + j))
            if left_arr[i] <= right_arr[j]:
                arr[k] = left_arr[i]
                steps.append(('swap', k, left_arr[i]))
                i += 1
            else:
                arr[k] = right_arr[j]
                steps.append(('swap', k, right_arr[j]))
                j += 1
            k += 1

        while i < len(left_arr):
            arr[k] = left_arr[i]
            steps.append(('swap', k, left_arr[i]))
            i += 1
            k += 1

        while j < len(right_arr):
            arr[k] = right_arr[j]
            steps.append(('swap', k, right_arr[j]))
            j += 1
            k += 1

        return steps

    arr_copy = array.copy()
    merge_sort(arr_copy, 0, len(arr_copy) - 1, steps)
    return steps, arr_copy


def run_sorting_module(screen, clock):
    WIDTH, HEIGHT = screen.get_size()

    ARRAY_SIZE = 30
    array = [random.randint(10, 350) for _ in range(ARRAY_SIZE)]
    original_array = array.copy()

    sorting_type = None
    sorting_active = False
    step = 0
    sorted_status = False
    compare_indices = None
    swap_indices = None
    sorted_indices = []

    bubble_btn = pygame.Rect(WIDTH // 2 - 200, HEIGHT - 100, 120, 40)
    selection_btn = pygame.Rect(WIDTH // 2 - 60, HEIGHT - 100, 120, 40)
    merge_btn = pygame.Rect(WIDTH // 2 + 80, HEIGHT - 100, 120, 40)
    reset_btn = pygame.Rect(WIDTH // 2 - 60, HEIGHT - 50, 120, 40)
    back_btn = pygame.Rect(20, HEIGHT - 50, 80, 35)

    instructions = [
        "SORTING ALGORITHMS VISUALIZATION",
        "Click BUBBLE, SELECTION, or MERGE to start sorting",
        "RESET to generate new random array | BACK to return"
    ]

    while True:
        screen.fill(GRAY)

        for i, instr in enumerate(instructions):
            text = FONT_SMALL.render(instr, True, BLACK)
            screen.blit(text, (20, 20 + i * 22))

        if sorting_active and sorting_type == "bubble":
            array, sorted_status, compare_indices, swap_indices = bubble_sort_step(array, step)
            if sorted_status:
                sorting_active = False
                sorted_indices = list(range(len(array)))
            else:
                if compare_indices:
                    step += 1
                else:
                    step += 1
            pygame.time.wait(20)

        elif sorting_active and sorting_type == "merge":
            if step < len(merge_steps):
                action = merge_steps[step]
                if action[0] == 'swap':
                    array[action[1]] = action[2]
                    swap_indices = [action[1]]
                    compare_indices = None
                elif action[0] == 'compare':
                    compare_indices = [action[1], action[2]]
                    swap_indices = None
                step += 1
                pygame.time.wait(30)

            else:
                sorting_active = False
                sorted_indices = list(range(len(array)))
                compare_indices = None
                swap_indices = None

        color_positions = {}
        if compare_indices:
            color_positions['compare'] = compare_indices
        if swap_indices:
            color_positions['swap'] = swap_indices
        if sorted_indices:
            color_positions['sorted'] = sorted_indices

        draw_array(screen, array, 50, 100, WIDTH - 100, 250, color_positions)

        mouse_pos = pygame.mouse.get_pos()

        if not sorting_active:
            bubble_color = BLUE if bubble_btn.collidepoint(mouse_pos) else DARK_BLUE
            selection_color = BLUE if selection_btn.collidepoint(mouse_pos) else DARK_BLUE
            merge_color = BLUE if merge_btn.collidepoint(mouse_pos) else DARK_BLUE
        else:
            bubble_color = GRAY
            selection_color = GRAY
            merge_color = GRAY

        pygame.draw.rect(screen, bubble_color, bubble_btn)
        pygame.draw.rect(screen, BLACK, bubble_btn, 2)
        bubble_text = FONT_SMALL.render("BUBBLE", True, BLACK)
        screen.blit(bubble_text, (bubble_btn.x + 25, bubble_btn.y + 10))

        pygame.draw.rect(screen, selection_color, selection_btn)
        pygame.draw.rect(screen, BLACK, selection_btn, 2)
        selection_text = FONT_SMALL.render("SELECTION", True, BLACK)
        screen.blit(selection_text, (selection_btn.x + 15, selection_btn.y + 10))

        pygame.draw.rect(screen, merge_color, merge_btn)
        pygame.draw.rect(screen, BLACK, merge_btn, 2)
        merge_text = FONT_SMALL.render("MERGE", True, BLACK)
        screen.blit(merge_text, (merge_btn.x + 25, merge_btn.y + 10))

        reset_color = GREEN if reset_btn.collidepoint(mouse_pos) else (100, 200, 100)
        pygame.draw.rect(screen, reset_color, reset_btn)
        pygame.draw.rect(screen, BLACK, reset_btn, 2)
        reset_text = FONT_SMALL.render("RESET", True, BLACK)
        screen.blit(reset_text, (reset_btn.x + 35, reset_btn.y + 10))

        pygame.draw.rect(screen, GRAY, back_btn)
        pygame.draw.rect(screen, BLACK, back_btn, 2)
        back_text = FONT_SMALL.render("BACK", True, BLACK)
        screen.blit(back_text, (back_btn.x + 20, back_btn.y + 8))

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if not sorting_active:
                    if bubble_btn.collidepoint(event.pos):
                        sorting_type = "bubble"
                        sorting_active = True
                        step = 0
                        array = original_array.copy()
                        sorted_indices = []
                        compare_indices = None
                        swap_indices = None
                    elif selection_btn.collidepoint(event.pos):
                        sorting_type = "selection"
                        sorting_active = True
                        step = 0
                        array = original_array.copy()
                        sorted_indices = []
                        compare_indices = None
                        swap_indices = None
                    elif merge_btn.collidepoint(event.pos):
                        sorting_type = "merge"
                        sorting_active = True
                        step = 0
                        array = original_array.copy()
                        sorted_indices = []
                        compare_indices = None
                        swap_indices = None
                        merge_steps, merge_final_array = merge_sort_step_by_step(original_array.copy())
                if reset_btn.collidepoint(event.pos):
                    array = [random.randint(10, 350) for _ in range(ARRAY_SIZE)]
                    original_array = array.copy()
                    sorting_active = False
                    sorting_type = None
                    step = 0
                    sorted_indices = []
                    compare_indices = None
                    swap_indices = None
                    merge_steps = []
                elif back_btn.collidepoint(event.pos):
                    return

        pygame.display.flip()
        clock.tick(60)