import pygame

WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
GRAY = (200, 200, 200)
BLUE = (100, 150, 250)
RED = (255, 100, 100)
GREEN = (100, 200, 100)
YELLOW = (255, 200, 100)
PURPLE = (200, 100, 255)
DARK_BLUE = (50, 100, 200)

FONT_SMALL = pygame.font.SysFont(None, 24)
FONT_MEDIUM = pygame.font.SysFont(None, 32)

def draw_button(screen, text, rect, color, hover_color, border_color=BLACK, border_width=2):
    mouse_pos = pygame.mouse.get_pos()
    current_color = hover_color if rect.collidepoint(mouse_pos) else color
    pygame.draw.rect(screen, current_color, rect)
    pygame.draw.rect(screen, border_color, rect, border_width)
    text_surf = FONT_SMALL.render(text, True, BLACK)
    text_rect = text_surf.get_rect(center=rect.center)
    screen.blit(text_surf, text_rect)
    return rect

def draw_text(screen, text, font, color, pos, center=False):
    surface = font.render(text, True, color)
    if center:
        rect = surface.get_rect(center=pos)
        screen.blit(surface, rect)
    else:
        screen.blit(surface, pos)

def wrap_text(text, font, max_width):
    words = text.split(' ')
    lines = []
    current_line = []
    for word in words:
        test_line = ' '.join(current_line + [word])
        if font.size(test_line)[0] <= max_width:
            current_line.append(word)
        else:
            if current_line:
                lines.append(' '.join(current_line))
            current_line = [word]
    if current_line:
        lines.append(' '.join(current_line))
    return lines