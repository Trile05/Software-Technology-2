import pygame
import sys

WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
GRAY = (200, 200, 200)
BLUE = (100, 150, 250)
RED = (255, 100, 100)
GREEN = (100, 200, 100)
YELLOW = (255, 200, 100)
PURPLE = (200, 100, 255)
ORANGE = (255, 165, 0)
DARK_BLUE = (50, 100, 200)

FONT_SMALL = pygame.font.SysFont(None, 24)
FONT_MEDIUM = pygame.font.SysFont(None, 28)


def grid_path_with_obstacles(screen, clock):
    WIDTH, HEIGHT = screen.get_size()
    ROWS, COLS = 6, 6
    CELL_SIZE = min((WIDTH - 200) // COLS, (HEIGHT - 200) // ROWS, 70)
    OFFSET_X = (WIDTH - CELL_SIZE * COLS) // 2
    OFFSET_Y = 100

    start = (0, 0)
    end = (ROWS - 1, COLS - 1)
    obstacles = set()
    dp = [[0 for _ in range(COLS)] for _ in range(ROWS)]
    path = []
    solved = False

    back_btn = pygame.Rect(20, HEIGHT - 50, 80, 35)
    reset_btn = pygame.Rect(WIDTH - 180, HEIGHT - 50, 80, 35)
    solve_btn = pygame.Rect(WIDTH - 90, HEIGHT - 50, 80, 35)

    instructions = [
        "DYNAMIC PROGRAMMING: GRID PATH WITH OBSTACLES",
        "Click cells to add/remove obstacles (black squares)",
        "SOLVE: Compute number of unique paths from top-left to bottom-right",
        "Green path shows one valid route (if exists)"
    ]

    def compute_dp():
        nonlocal dp, solved
        for r in range(ROWS):
            for c in range(COLS):
                if (r, c) in obstacles:
                    dp[r][c] = 0
                elif r == 0 and c == 0:
                    dp[r][c] = 1
                else:
                    up = dp[r - 1][c] if r > 0 else 0
                    left = dp[r][c - 1] if c > 0 else 0
                    dp[r][c] = up + left
        solved = True

    def reconstruct_path():
        nonlocal path
        path = []
        if dp[end[0]][end[1]] == 0:
            return

        r, c = end
        while (r, c) != start:
            path.append((r, c))
            if r > 0 and dp[r - 1][c] > 0:
                r -= 1
            elif c > 0 and dp[r][c - 1] > 0:
                c -= 1
            else:
                break
        path.append(start)
        path.reverse()

    def draw_grid():
        screen.fill(GRAY)

        for i, instr in enumerate(instructions):
            text = FONT_SMALL.render(instr, True, BLACK)
            screen.blit(text, (20, 20 + i * 22))

        for r in range(ROWS):
            for c in range(COLS):
                rect = pygame.Rect(OFFSET_X + c * CELL_SIZE, OFFSET_Y + r * CELL_SIZE, CELL_SIZE, CELL_SIZE)

                if (r, c) in obstacles:
                    color = BLACK
                elif (r, c) == start:
                    color = PURPLE
                elif (r, c) == end:
                    color = RED
                elif (r, c) in path:
                    color = GREEN
                elif solved and dp[r][c] > 0:
                    intensity = min(200, 50 + dp[r][c] % 150)
                    color = (100, 150, intensity)
                else:
                    color = WHITE

                pygame.draw.rect(screen, color, rect)
                pygame.draw.rect(screen, BLACK, rect, 1)

                if solved and dp[r][c] > 0 and (r, c) not in obstacles and (r, c) not in path and (r, c) != start and (
                        r, c) != end:
                    text = FONT_SMALL.render(str(dp[r][c]), True, BLACK)
                    text_rect = text.get_rect(center=rect.center)
                    screen.blit(text, text_rect)

        mouse_pos = pygame.mouse.get_pos()

        reset_color = YELLOW if reset_btn.collidepoint(mouse_pos) else (255, 220, 100)
        pygame.draw.rect(screen, reset_color, reset_btn)
        pygame.draw.rect(screen, BLACK, reset_btn, 2)
        reset_text = FONT_SMALL.render("RESET", True, BLACK)
        screen.blit(reset_text, (reset_btn.x + 18, reset_btn.y + 10))

        solve_color = GREEN if solve_btn.collidepoint(mouse_pos) else (100, 200, 100)
        pygame.draw.rect(screen, solve_color, solve_btn)
        pygame.draw.rect(screen, BLACK, solve_btn, 2)
        solve_text = FONT_SMALL.render("SOLVE", True, BLACK)
        screen.blit(solve_text, (solve_btn.x + 20, solve_btn.y + 10))

        pygame.draw.rect(screen, GRAY, back_btn)
        pygame.draw.rect(screen, BLACK, back_btn, 2)
        back_text = FONT_SMALL.render("BACK", True, BLACK)
        screen.blit(back_text, (back_btn.x + 20, back_btn.y + 10))

        mode_text = FONT_SMALL.render("Click any cell to add/remove obstacle", True, DARK_BLUE)
        screen.blit(mode_text, (20, HEIGHT - 80))

        if solved:
            result_text = FONT_SMALL.render(f"Total unique paths: {dp[end[0]][end[1]]}", True, DARK_BLUE)
            screen.blit(result_text, (20, HEIGHT - 100))

    running = True
    while running:
        draw_grid()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if back_btn.collidepoint(event.pos):
                    return
                elif reset_btn.collidepoint(event.pos):
                    obstacles = set()
                    dp = [[0 for _ in range(COLS)] for _ in range(ROWS)]
                    path = []
                    solved = False
                elif solve_btn.collidepoint(event.pos):
                    compute_dp()
                    reconstruct_path()
                else:
                    x, y = event.pos
                    col = (x - OFFSET_X) // CELL_SIZE
                    row = (y - OFFSET_Y) // CELL_SIZE
                    if 0 <= row < ROWS and 0 <= col < COLS:
                        cell = (row, col)
                        if cell != start and cell != end:
                            if cell in obstacles:
                                obstacles.remove(cell)
                            else:
                                obstacles.add(cell)
                            solved = False
                            path = []
                            dp = [[0 for _ in range(COLS)] for _ in range(ROWS)]

        pygame.display.flip()
        clock.tick(30)


def coin_change_visualization(screen, clock):
    WIDTH, HEIGHT = screen.get_size()

    coins = [1, 5, 10, 25]
    amount = 37
    dp = [float('inf')] * (amount + 1)
    dp[0] = 0
    coin_used = [-1] * (amount + 1)

    for i in range(1, amount + 1):
        for coin in coins:
            if i - coin >= 0 and dp[i - coin] + 1 < dp[i]:
                dp[i] = dp[i - coin] + 1
                coin_used[i] = coin

    def get_coin_combination(amt):
        combo = []
        while amt > 0:
            coin = coin_used[amt]
            combo.append(coin)
            amt -= coin
        return combo

    amount_input = str(amount)
    message = ""
    message_timer = 0
    caret_visible = True
    caret_timer = 0
    active_input = False

    back_btn = pygame.Rect(20, HEIGHT - 50, 80, 35)
    solve_btn = pygame.Rect(WIDTH - 110, HEIGHT - 50, 90, 40)

    instructions = [
        "DYNAMIC PROGRAMMING: COIN CHANGE PROBLEM",
        "Find minimum number of coins to make a target amount",
        f"Available coins: {coins}",
        "Click the input box, type a number, then click SOLVE"
    ]

    running = True
    while running:
        screen.fill(GRAY)

        for i, instr in enumerate(instructions):
            text = FONT_SMALL.render(instr, True, BLACK)
            screen.blit(text, (20, 20 + i * 22))

        input_label = FONT_MEDIUM.render("Target Amount:", True, DARK_BLUE)
        screen.blit(input_label, (WIDTH // 2.1 - 180, 180))

        input_rect = pygame.Rect(WIDTH // 2 - 50, 175, 120, 40)
        pygame.draw.rect(screen, WHITE, input_rect)
        pygame.draw.rect(screen, BLACK, input_rect, 2)

        display_text = amount_input
        if active_input and caret_visible:
            display_text = amount_input + "|"
        input_text = FONT_MEDIUM.render(display_text, True, BLACK)
        screen.blit(input_text, (input_rect.x + 10, input_rect.y + 8))

        target_text = FONT_MEDIUM.render(f"Target: {amount}", True, DARK_BLUE)
        screen.blit(target_text, (WIDTH // 2 - 50, 230))

        mouse_pos = pygame.mouse.get_pos()

        solve_color = GREEN if solve_btn.collidepoint(mouse_pos) else (100, 200, 100)
        pygame.draw.rect(screen, solve_color, solve_btn)
        pygame.draw.rect(screen, BLACK, solve_btn, 2)
        solve_text = FONT_SMALL.render("SOLVE", True, BLACK)
        solve_text_rect = solve_text.get_rect(center=solve_btn.center)
        screen.blit(solve_text, solve_text_rect)

        pygame.draw.rect(screen, GRAY, back_btn)
        pygame.draw.rect(screen, BLACK, back_btn, 2)
        back_text = FONT_SMALL.render("BACK", True, BLACK)
        back_text_rect = back_text.get_rect(center=back_btn.center)
        screen.blit(back_text, back_text_rect)

        if dp[amount] != float('inf'):
            result_text = FONT_MEDIUM.render(f"Minimum coins needed: {dp[amount]}", True, GREEN)
            screen.blit(result_text, (WIDTH // 2 - 130, 280))

            combo = get_coin_combination(amount)

            combo_display = "Coins used: " + ", ".join(str(c) for c in combo[:20])
            if len(combo) > 20:
                combo_display += f" ... and {len(combo) - 20} more"

            combo_text = FONT_SMALL.render(combo_display, True, BLUE)
            combo_rect = combo_text.get_rect(center=(WIDTH // 2, 320))
            screen.blit(combo_text, combo_rect)

            y_offset = 370
            start_x = WIDTH // 2 - min(len(combo), 10) * 28
            max_coins_to_show = min(len(combo), 12)

            for i, coin_val in enumerate(combo[:max_coins_to_show]):
                x_offset = start_x + i * 55
                if x_offset + 30 > WIDTH - 50:
                    break
                pygame.draw.circle(screen, YELLOW, (x_offset, y_offset), 25)
                pygame.draw.circle(screen, BLACK, (x_offset, y_offset), 25, 2)
                coin_text = FONT_MEDIUM.render(str(coin_val), True, BLACK)
                text_rect = coin_text.get_rect(center=(x_offset, y_offset))
                screen.blit(coin_text, text_rect)

            if len(combo) > max_coins_to_show:
                more_text = FONT_SMALL.render(f"+ {len(combo) - max_coins_to_show} more coins", True, RED)
                screen.blit(more_text, (start_x + max_coins_to_show * 55, y_offset + 10))

        if message_timer > 0:
            msg_text = FONT_SMALL.render(message, True, RED)
            screen.blit(msg_text, (WIDTH // 2 - 100, 450))
            message_timer -= 1

        caret_timer += 1
        if caret_timer >= 30:
            caret_timer = 0
            caret_visible = not caret_visible

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if back_btn.collidepoint(event.pos):
                    return
                elif solve_btn.collidepoint(event.pos):
                    try:
                        amount = int(amount_input)
                        if amount < 0:
                            amount = 0
                        dp = [float('inf')] * (amount + 1)
                        dp[0] = 0
                        coin_used = [-1] * (amount + 1)
                        for i in range(1, amount + 1):
                            for coin in coins:
                                if i - coin >= 0 and dp[i - coin] + 1 < dp[i]:
                                    dp[i] = dp[i - coin] + 1
                                    coin_used[i] = coin
                        message = f"Solved for amount {amount}"
                        message_timer = 60
                    except ValueError:
                        message = "Invalid amount"
                        message_timer = 60
                elif input_rect.collidepoint(event.pos):
                    active_input = True
                else:
                    active_input = False
            elif event.type == pygame.KEYDOWN:
                if active_input:
                    if event.key == pygame.K_RETURN:
                        try:
                            amount = int(amount_input)
                            if amount < 0:
                                amount = 0
                            dp = [float('inf')] * (amount + 1)
                            dp[0] = 0
                            coin_used = [-1] * (amount + 1)
                            for i in range(1, amount + 1):
                                for coin in coins:
                                    if i - coin >= 0 and dp[i - coin] + 1 < dp[i]:
                                        dp[i] = dp[i - coin] + 1
                                        coin_used[i] = coin
                            message = f"Solved for amount {amount}"
                            message_timer = 60
                        except ValueError:
                            message = "Invalid amount"
                            message_timer = 60
                        active_input = False
                    elif event.key == pygame.K_BACKSPACE:
                        amount_input = amount_input[:-1]
                    elif event.key == pygame.K_ESCAPE:
                        active_input = False
                    elif event.unicode.isdigit():
                        amount_input += event.unicode
                elif event.key == pygame.K_ESCAPE:
                    running = False

        pygame.display.flip()
        clock.tick(30)


def draw_text(screen, text, font, color, pos, center=False):
    surface = font.render(text, True, color)
    if center:
        rect = surface.get_rect(center=pos)
        screen.blit(surface, rect)
    else:
        screen.blit(surface, pos)


def run_dp_module(screen, clock):
    WIDTH, HEIGHT = screen.get_size()

    grid_btn = pygame.Rect(WIDTH // 2 - 120, 200, 240, 50)
    coin_btn = pygame.Rect(WIDTH // 2 - 120, 280, 240, 50)
    back_btn = pygame.Rect(WIDTH // 2 - 60, 360, 120, 50)

    while True:
        screen.fill(GRAY)
        draw_text(screen, "DYNAMIC PROGRAMMING", FONT_MEDIUM, DARK_BLUE,
                  (WIDTH // 2, 80), center=True)

        mouse_pos = pygame.mouse.get_pos()

        grid_color = BLUE if grid_btn.collidepoint(mouse_pos) else DARK_BLUE
        pygame.draw.rect(screen, grid_color, grid_btn)
        pygame.draw.rect(screen, BLACK, grid_btn, 2)
        grid_text = FONT_MEDIUM.render("GRID PATH (OBSTACLES)", True, WHITE)
        grid_rect = grid_text.get_rect(center=grid_btn.center)
        screen.blit(grid_text, grid_rect)

        coin_color = BLUE if coin_btn.collidepoint(mouse_pos) else DARK_BLUE
        pygame.draw.rect(screen, coin_color, coin_btn)
        pygame.draw.rect(screen, BLACK, coin_btn, 2)
        coin_text = FONT_MEDIUM.render("COIN CHANGE", True, WHITE)
        coin_rect = coin_text.get_rect(center=coin_btn.center)
        screen.blit(coin_text, coin_rect)

        pygame.draw.rect(screen, GRAY, back_btn)
        pygame.draw.rect(screen, BLACK, back_btn, 2)
        back_text = FONT_MEDIUM.render("BACK", True, BLACK)
        back_rect = back_text.get_rect(center=back_btn.center)
        screen.blit(back_text, back_rect)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if grid_btn.collidepoint(event.pos):
                    grid_path_with_obstacles(screen, clock)
                elif coin_btn.collidepoint(event.pos):
                    coin_change_visualization(screen, clock)
                elif back_btn.collidepoint(event.pos):
                    return

        pygame.display.flip()
        clock.tick(30)