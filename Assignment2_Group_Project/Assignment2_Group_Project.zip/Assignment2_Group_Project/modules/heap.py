import pygame
import sys
import random
import math

WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
GRAY = (200, 200, 200)
BLUE = (100, 150, 250)
RED = (255, 100, 100)
GREEN = (100, 200, 100)
YELLOW = (255, 200, 100)
DARK_BLUE = (50, 100, 200)

FONT_SMALL = pygame.font.SysFont(None, 24)
FONT_MEDIUM = pygame.font.SysFont(None, 28)


class MinHeap:
    def __init__(self):
        self.heap = []

    def parent(self, i):
        return (i - 1) // 2

    def left_child(self, i):
        return 2 * i + 1

    def right_child(self, i):
        return 2 * i + 2

    def insert(self, val):
        self.heap.append(val)
        self._heapify_up(len(self.heap) - 1)

    def _heapify_up(self, i):
        while i > 0 and self.heap[self.parent(i)] > self.heap[i]:
            self.heap[self.parent(i)], self.heap[i] = self.heap[i], self.heap[self.parent(i)]
            i = self.parent(i)

    def extract_min(self):
        if not self.heap:
            return None
        if len(self.heap) == 1:
            return self.heap.pop()

        root = self.heap[0]
        self.heap[0] = self.heap.pop()
        self._heapify_down(0)
        return root

    def _heapify_down(self, i):
        n = len(self.heap)
        while True:
            smallest = i
            left = self.left_child(i)
            right = self.right_child(i)

            if left < n and self.heap[left] < self.heap[smallest]:
                smallest = left
            if right < n and self.heap[right] < self.heap[smallest]:
                smallest = right

            if smallest != i:
                self.heap[i], self.heap[smallest] = self.heap[smallest], self.heap[i]
                i = smallest
            else:
                break

    def get_heap(self):
        return self.heap.copy()


def draw_heap(screen, heap, highlight_indices=[]):
    if not heap:
        return

    WIDTH, HEIGHT = screen.get_size()
    levels = int(math.log2(len(heap))) + 1
    max_nodes_in_level = 2 ** (levels - 1)

    node_positions = []
    start_x = max(50, (WIDTH - max_nodes_in_level * 70) // 2)

    for i in range(len(heap)):
        level = int(math.floor(math.log2(i + 1)))
        index_in_level = i - (2 ** level - 1)
        nodes_in_level = 2 ** level
        spacing = min(70, (WIDTH - 100) // nodes_in_level)
        x = 50 + index_in_level * spacing + (WIDTH - nodes_in_level * spacing) // 2
        y = 80 + level * 70
        node_positions.append((x, y))

    for i in range(len(heap)):
        left = 2 * i + 1
        right = 2 * i + 2
        if left < len(heap):
            pygame.draw.line(screen, BLACK, node_positions[i], node_positions[left], 2)
        if right < len(heap):
            pygame.draw.line(screen, BLACK, node_positions[i], node_positions[right], 2)

    for i, val in enumerate(heap):
        color = BLUE
        if i in highlight_indices:
            color = RED

        pygame.draw.circle(screen, color, node_positions[i], 25)
        pygame.draw.circle(screen, BLACK, node_positions[i], 25, 2)
        text = FONT_MEDIUM.render(str(val), True, BLACK)
        text_rect = text.get_rect(center=node_positions[i])
        screen.blit(text, text_rect)


def heap_visualization(screen, clock):
    heap = MinHeap()
    WIDTH, HEIGHT = screen.get_size()

    insert_btn = pygame.Rect(WIDTH // 2 - 120, HEIGHT - 100, 100, 40)
    extract_btn = pygame.Rect(WIDTH // 2, HEIGHT - 100, 100, 40)
    random_btn = pygame.Rect(WIDTH // 2 - 60, HEIGHT - 50, 120, 40)
    back_btn = pygame.Rect(20, HEIGHT - 50, 80, 35)

    instructions = [
        "MIN-HEAP VISUALIZATION",
        "INSERT: Add random number (1-100)",
        "EXTRACT-MIN: Remove smallest element",
        "RANDOM: Generate 10 random numbers"
    ]

    running = True
    while running:
        screen.fill(GRAY)

        for i, instr in enumerate(instructions):
            text = FONT_SMALL.render(instr, True, BLACK)
            screen.blit(text, (20, 20 + i * 22))

        draw_heap(screen, heap.get_heap(), [])

        mouse_pos = pygame.mouse.get_pos()

        insert_color = GREEN if insert_btn.collidepoint(mouse_pos) else (100, 200, 100)
        pygame.draw.rect(screen, insert_color, insert_btn)
        pygame.draw.rect(screen, BLACK, insert_btn, 2)
        insert_text = FONT_SMALL.render("INSERT", True, BLACK)
        screen.blit(insert_text, (insert_btn.x + 20, insert_btn.y + 10))

        extract_color = RED if extract_btn.collidepoint(mouse_pos) else (255, 150, 150)
        pygame.draw.rect(screen, extract_color, extract_btn)
        pygame.draw.rect(screen, BLACK, extract_btn, 2)
        extract_text = FONT_SMALL.render("EXTRACT", True, BLACK)
        screen.blit(extract_text, (extract_btn.x + 15, extract_btn.y + 10))

        random_color = YELLOW if random_btn.collidepoint(mouse_pos) else (255, 220, 100)
        pygame.draw.rect(screen, random_color, random_btn)
        pygame.draw.rect(screen, BLACK, random_btn, 2)
        random_text = FONT_SMALL.render("RANDOM", True, BLACK)
        screen.blit(random_text, (random_btn.x + 25, random_btn.y + 10))

        pygame.draw.rect(screen, GRAY, back_btn)
        pygame.draw.rect(screen, BLACK, back_btn, 2)
        back_text = FONT_SMALL.render("BACK", True, BLACK)
        screen.blit(back_text, (back_btn.x + 20, back_btn.y + 8))

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if insert_btn.collidepoint(event.pos):
                    val = random.randint(1, 100)
                    heap.insert(val)
                elif extract_btn.collidepoint(event.pos):
                    extracted = heap.extract_min()
                    if extracted is not None:
                        pass
                elif random_btn.collidepoint(event.pos):
                    heap.heap = []
                    for _ in range(10):
                        heap.insert(random.randint(1, 100))
                elif back_btn.collidepoint(event.pos):
                    running = False

        pygame.display.flip()
        clock.tick(30)


class Event:
    def __init__(self, time, description):
        self.time = time
        self.description = description

    def __lt__(self, other):
        return self.time < other.time

    def __repr__(self):
        return f"[{self.time}] {self.description}"


class EventQueue:
    def __init__(self):
        self.heap = []

    def add_event(self, time, description):
        event = Event(time, description)
        self.heap.append(event)
        self._heapify_up(len(self.heap) - 1)

    def _heapify_up(self, i):
        while i > 0 and self.heap[(i - 1) // 2].time > self.heap[i].time:
            self.heap[(i - 1) // 2], self.heap[i] = self.heap[i], self.heap[(i - 1) // 2]
            i = (i - 1) // 2

    def _heapify_down(self, i):
        n = len(self.heap)
        while True:
            smallest = i
            left = 2 * i + 1
            right = 2 * i + 2

            if left < n and self.heap[left].time < self.heap[smallest].time:
                smallest = left
            if right < n and self.heap[right].time < self.heap[smallest].time:
                smallest = right

            if smallest != i:
                self.heap[i], self.heap[smallest] = self.heap[smallest], self.heap[i]
                i = smallest
            else:
                break

    def get_next_event(self):
        if not self.heap:
            return None
        if len(self.heap) == 1:
            return self.heap.pop()

        root = self.heap[0]
        self.heap[0] = self.heap.pop()
        self._heapify_down(0)
        return root

    def peek_next(self):
        return self.heap[0] if self.heap else None

    def size(self):
        return len(self.heap)

    def get_all_events(self):
        return self.heap.copy()


def event_simulator(screen, clock):
    eq = EventQueue()
    WIDTH, HEIGHT = screen.get_size()

    event_templates = [
        ("Meeting with team", 5),
        ("Submit assignment", 10),
        ("Lunch break", 15),
        ("Code review", 20),
        ("Project presentation", 25),
        ("Coffee break", 30),
        ("Bug fixing session", 35),
        ("Documentation update", 40),
        ("Client call", 45),
        ("End of day wrap-up", 50),
    ]

    for desc, time in event_templates:
        eq.add_event(time, desc)

    add_btn = pygame.Rect(WIDTH // 2 - 120, HEIGHT - 100, 100, 40)
    process_btn = pygame.Rect(WIDTH // 2, HEIGHT - 100, 100, 40)
    reset_btn = pygame.Rect(WIDTH // 2 - 60, HEIGHT - 50, 120, 40)
    back_btn = pygame.Rect(20, HEIGHT - 50, 80, 35)

    current_event = None
    message = ""
    message_timer = 0

    instructions = [
        "EVENT SIMULATOR (Priority Queue using Min-Heap)",
        "Events are ordered by time (priority)",
        "PROCESS: Pop and execute the earliest event",
        "RESET: Reload all events"
    ]

    running = True
    while running:
        screen.fill(GRAY)

        for i, instr in enumerate(instructions):
            text = FONT_SMALL.render(instr, True, BLACK)
            screen.blit(text, (20, 20 + i * 22))

        events = eq.get_all_events()
        sorted_events = sorted(events, key=lambda e: e.time)

        y_offset = 150
        for i, event in enumerate(sorted_events[:8]):
            color = GREEN if i == 0 else BLACK
            event_text = FONT_SMALL.render(f"{event.time:3d} : {event.description}", True, color)
            screen.blit(event_text, (50, y_offset + i * 30))

        if eq.size() == 0:
            empty_text = FONT_MEDIUM.render("No events remaining!", True, RED)
            screen.blit(empty_text, (WIDTH // 2 - 100, HEIGHT // 2))

        if current_event:
            current_text = FONT_MEDIUM.render(f"PROCESSING: {current_event.description} at time {current_event.time}",
                                              True, RED)
            screen.blit(current_text, (WIDTH // 2 - 200, HEIGHT - 180))

        if message_timer > 0:
            msg_text = FONT_SMALL.render(message, True, RED)
            screen.blit(msg_text, (WIDTH // 2 - 100, HEIGHT - 150))
            message_timer -= 1

        upcoming_text = FONT_SMALL.render("Upcoming Events (earliest first):", True, DARK_BLUE)
        screen.blit(upcoming_text, (50, 120))

        mouse_pos = pygame.mouse.get_pos()

        add_color = GREEN if add_btn.collidepoint(mouse_pos) else (100, 200, 100)
        pygame.draw.rect(screen, add_color, add_btn)
        pygame.draw.rect(screen, BLACK, add_btn, 2)
        add_text = FONT_SMALL.render("ADD", True, BLACK)
        screen.blit(add_text, (add_btn.x + 30, add_btn.y + 10))

        process_color = YELLOW if process_btn.collidepoint(mouse_pos) else (255, 220, 100)
        pygame.draw.rect(screen, process_color, process_btn)
        pygame.draw.rect(screen, BLACK, process_btn, 2)
        process_text = FONT_SMALL.render("PROCESS", True, BLACK)
        screen.blit(process_text, (process_btn.x + 15, process_btn.y + 10))

        reset_color = BLUE if reset_btn.collidepoint(mouse_pos) else DARK_BLUE
        pygame.draw.rect(screen, reset_color, reset_btn)
        pygame.draw.rect(screen, BLACK, reset_btn, 2)
        reset_text = FONT_SMALL.render("RESET", True, BLACK)
        screen.blit(reset_text, (reset_btn.x + 35, reset_btn.y + 10))

        pygame.draw.rect(screen, GRAY, back_btn)
        pygame.draw.rect(screen, BLACK, back_btn, 2)
        back_text = FONT_SMALL.render("BACK", True, BLACK)
        screen.blit(back_text, (back_btn.x + 20, back_btn.y + 8))

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if add_btn.collidepoint(event.pos):
                    new_time = random.randint(1, 60)
                    new_desc = f"Custom event at {new_time}"
                    eq.add_event(new_time, new_desc)
                    message = f"Added: {new_desc}"
                    message_timer = 60
                    current_event = None
                elif process_btn.collidepoint(event.pos):
                    current_event = eq.get_next_event()
                    if current_event:
                        message = f"Processed: {current_event.description}"
                        message_timer = 60
                    else:
                        message = "No events to process!"
                        message_timer = 60
                elif reset_btn.collidepoint(event.pos):
                    eq.heap = []
                    for desc, time in event_templates:
                        eq.add_event(time, desc)
                    current_event = None
                    message = "Events reset!"
                    message_timer = 60
                elif back_btn.collidepoint(event.pos):
                    running = False

        pygame.display.flip()
        clock.tick(30)


def draw_text(screen, text, font, color, pos, center=False):
    surface = font.render(text, True, color)
    if center:
        rect = surface.get_rect(center=pos)
        screen.blit(surface, rect)
    else:
        screen.blit(surface, pos)


def run_heap_module(screen, clock):
    WIDTH, HEIGHT = screen.get_size()

    heap_btn = pygame.Rect(WIDTH // 2 - 120, 200, 240, 50)
    event_btn = pygame.Rect(WIDTH // 2 - 120, 280, 240, 50)
    back_btn = pygame.Rect(WIDTH // 2 - 60, 360, 120, 50)

    while True:
        screen.fill(GRAY)
        draw_text(screen, "HEAP & EVENT SIMULATOR", FONT_MEDIUM, DARK_BLUE,
                  (WIDTH // 2, 80), center=True)

        mouse_pos = pygame.mouse.get_pos()

        heap_color = BLUE if heap_btn.collidepoint(mouse_pos) else DARK_BLUE
        pygame.draw.rect(screen, heap_color, heap_btn)
        pygame.draw.rect(screen, BLACK, heap_btn, 2)
        heap_text = FONT_MEDIUM.render("HEAP VISUALIZATION", True, WHITE)
        heap_rect = heap_text.get_rect(center=heap_btn.center)
        screen.blit(heap_text, heap_rect)

        event_color = BLUE if event_btn.collidepoint(mouse_pos) else DARK_BLUE
        pygame.draw.rect(screen, event_color, event_btn)
        pygame.draw.rect(screen, BLACK, event_btn, 2)
        event_text = FONT_MEDIUM.render("EVENT SIMULATOR", True, WHITE)
        event_rect = event_text.get_rect(center=event_btn.center)
        screen.blit(event_text, event_rect)

        pygame.draw.rect(screen, GRAY, back_btn)
        pygame.draw.rect(screen, BLACK, back_btn, 2)
        back_text = FONT_MEDIUM.render("BACK", True, BLACK)
        back_rect = back_text.get_rect(center=back_btn.center)
        screen.blit(back_text, back_rect)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if heap_btn.collidepoint(event.pos):
                    heap_visualization(screen, clock)
                elif event_btn.collidepoint(event.pos):
                    event_simulator(screen, clock)
                elif back_btn.collidepoint(event.pos):
                    return

        pygame.display.flip()
        clock.tick(30)