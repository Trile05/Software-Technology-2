import pygame
import sys
import collections
import heapq

WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
GRAY = (200, 200, 200)
BLUE = (100, 150, 250)
RED = (255, 100, 100)
GREEN = (100, 200, 100)
YELLOW = (255, 200, 100)
PURPLE = (200, 100, 255)
ORANGE = (255, 165, 0)
DARK_BLUE = (50, 100, 200)

FONT_SMALL = pygame.font.SysFont(None, 24)
FONT_MEDIUM = pygame.font.SysFont(None, 28)

nodes_pos = {
    'A': (150, 150),
    'B': (300, 80),
    'C': (300, 250),
    'D': (450, 120),
    'E': (550, 200),
    'F': (450, 320),
    'G': (650, 300),
    'H': (750, 150),
}

graph = {
    'A': ['B', 'C'],
    'B': ['A', 'D', 'E'],
    'C': ['A', 'F'],
    'D': ['B', 'G'],
    'E': ['B', 'F', 'G'],
    'F': ['C', 'E', 'H'],
    'G': ['D', 'E', 'H'],
    'H': ['F', 'G'],
}

edge_weights = {
    ('A', 'B'): 4, ('B', 'A'): 4,
    ('A', 'C'): 3, ('C', 'A'): 3,
    ('B', 'D'): 2, ('D', 'B'): 2,
    ('B', 'E'): 5, ('E', 'B'): 5,
    ('C', 'F'): 6, ('F', 'C'): 6,
    ('D', 'G'): 3, ('G', 'D'): 3,
    ('E', 'F'): 2, ('F', 'E'): 2,
    ('E', 'G'): 4, ('G', 'E'): 4,
    ('F', 'H'): 5, ('H', 'F'): 5,
    ('G', 'H'): 3, ('H', 'G'): 3,
}


def draw_graph(screen, visited=set(), frontier=set(), current=None, start_node=None, traversal_order=None):
    screen.fill(GRAY)
    WIDTH, HEIGHT = screen.get_size()

    for node, neighbors in graph.items():
        x1, y1 = nodes_pos[node]
        for n in neighbors:
            x2, y2 = nodes_pos[n]
            pygame.draw.line(screen, BLACK, (x1, y1), (x2, y2), 2)

    for node, (x, y) in nodes_pos.items():
        color = BLUE
        if node == start_node:
            color = PURPLE
        if node in visited:
            color = GREEN
        if node in frontier:
            color = YELLOW
        if node == current:
            color = RED

        pygame.draw.circle(screen, color, (x, y), 30)
        pygame.draw.circle(screen, BLACK, (x, y), 30, 2)
        text = FONT_MEDIUM.render(node, True, BLACK)
        text_rect = text.get_rect(center=(x, y))
        screen.blit(text, text_rect)

    if traversal_order:
        order_text = FONT_SMALL.render(f"Traversal Order: {' -> '.join(traversal_order)}", True, DARK_BLUE)
        screen.blit(order_text, (20, 20))


def draw_graph_with_mst(screen, visited=set(), mst_edges=set(), current_node=None, start_node=None):
    screen.fill(GRAY)
    WIDTH, HEIGHT = screen.get_size()

    for node, neighbors in graph.items():
        x1, y1 = nodes_pos[node]
        for n in neighbors:
            x2, y2 = nodes_pos[n]
            if (node, n) in mst_edges or (n, node) in mst_edges:
                color = GREEN
                width = 4
            else:
                color = BLACK
                width = 2
            pygame.draw.line(screen, color, (x1, y1), (x2, y2), width)

            weight = edge_weights.get((node, n))
            if weight:
                mid_x = (x1 + x2) // 2
                mid_y = (y1 + y2) // 2
                weight_text = FONT_SMALL.render(str(weight), True, RED)
                screen.blit(weight_text, (mid_x, mid_y))

    for node, (x, y) in nodes_pos.items():
        color = BLUE
        if node == start_node:
            color = PURPLE
        if node in visited:
            color = YELLOW
        if node == current_node:
            color = RED

        pygame.draw.circle(screen, color, (x, y), 30)
        pygame.draw.circle(screen, BLACK, (x, y), 30, 2)
        text = FONT_MEDIUM.render(node, True, BLACK)
        text_rect = text.get_rect(center=(x, y))
        screen.blit(text, text_rect)


def prim_mst_visualization(screen, clock, start):
    WIDTH, HEIGHT = screen.get_size()
    visited = set()
    mst_edges = set()
    pq = []
    total_cost = 0

    visited.add(start)

    for neighbor in graph[start]:
        weight = edge_weights.get((start, neighbor), edge_weights.get((neighbor, start)))
        heapq.heappush(pq, (weight, start, neighbor))

    while pq and len(visited) < len(graph):
        weight, u, v = heapq.heappop(pq)

        if v in visited:
            continue

        visited.add(v)
        mst_edges.add((u, v))
        total_cost += weight

        draw_graph_with_mst(screen, visited, mst_edges, v, start)

        cost_text = FONT_SMALL.render(f"MST Total Cost: {total_cost}", True, DARK_BLUE)
        screen.blit(cost_text, (20, HEIGHT - 60))

        pygame.display.flip()
        pygame.time.wait(800)

        for neighbor in graph[v]:
            if neighbor not in visited:
                w = edge_weights.get((v, neighbor), edge_weights.get((neighbor, v)))
                heapq.heappush(pq, (w, v, neighbor))

    draw_graph_with_mst(screen, visited, mst_edges, None, start)
    cost_text = FONT_MEDIUM.render(f"Minimum Spanning Tree Complete! Total Cost: {total_cost}", True, GREEN)
    screen.blit(cost_text, (WIDTH // 2 - 200, HEIGHT - 100))
    pygame.display.flip()
    pygame.time.wait(2000)


def bfs_visualization(screen, clock, start):
    WIDTH, HEIGHT = screen.get_size()
    visited = set()
    traversal_order = []
    queue = collections.deque([start])
    frontier = set([start])
    paused = False

    while queue:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    return
                elif event.key == pygame.K_SPACE:
                    paused = not paused

        if paused:
            clock.tick(30)
            continue

        current = queue.popleft()
        if current in visited:
            continue
        visited.add(current)
        traversal_order.append(current)
        frontier.discard(current)

        draw_graph(screen, visited, frontier, current, start, traversal_order)
        pygame.display.flip()
        pygame.time.wait(300)

        for neighbor in graph[current]:
            if neighbor not in visited and neighbor not in queue:
                queue.append(neighbor)
                frontier.add(neighbor)

    draw_graph(screen, visited, set(), None, start, traversal_order)
    pygame.display.flip()
    pygame.time.wait(1000)


def dfs_visualization(screen, clock, start):
    WIDTH, HEIGHT = screen.get_size()
    visited = set()
    traversal_order = []
    stack = [start]
    paused = False

    while stack:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    return
                elif event.key == pygame.K_SPACE:
                    paused = not paused

        if paused:
            clock.tick(30)
            continue

        current = stack.pop()
        if current in visited:
            continue
        visited.add(current)
        traversal_order.append(current)

        draw_graph(screen, visited, set(stack), current, start, traversal_order)
        pygame.display.flip()
        pygame.time.wait(300)

        for neighbor in reversed(graph[current]):
            if neighbor not in visited:
                stack.append(neighbor)

    draw_graph(screen, visited, set(), None, start, traversal_order)
    pygame.display.flip()
    pygame.time.wait(1000)


def run_graphs_module(screen, clock):
    WIDTH, HEIGHT = screen.get_size()

    start_node = 'A'
    selected = False

    mst_btn = pygame.Rect(WIDTH - 200, HEIGHT - 80, 180, 45)
    back_btn = pygame.Rect(20, HEIGHT - 50, 80, 35)

    instructions = [
        "GRAPH ALGORITHMS VISUALIZATION",
        "1. Click on a node to select start point",
        "2. Press B for BFS | Press D for DFS",
        "3. Click MST button on the right for Minimum Spanning Tree (Prim's Algorithm)"
    ]

    def wait_for_selection():
        nonlocal start_node, selected
        waiting = True
        while waiting:
            screen.fill(GRAY)

            for i, instr in enumerate(instructions):
                text = FONT_SMALL.render(instr, True, BLACK)
                screen.blit(text, (20, 20 + i * 22))

            draw_graph(screen, set(), set(), None, start_node, None)

            mouse_pos = pygame.mouse.get_pos()

            mst_color = GREEN if mst_btn.collidepoint(mouse_pos) else (100, 200, 100)
            pygame.draw.rect(screen, mst_color, mst_btn)
            pygame.draw.rect(screen, BLACK, mst_btn, 2)
            mst_text = FONT_SMALL.render("MST (Prim's)", True, BLACK)
            mst_text_rect = mst_text.get_rect(center=mst_btn.center)
            screen.blit(mst_text, mst_text_rect)

            pygame.draw.rect(screen, GRAY, back_btn)
            pygame.draw.rect(screen, BLACK, back_btn, 2)
            back_text = FONT_SMALL.render("BACK", True, BLACK)
            screen.blit(back_text, (back_btn.x + 20, back_btn.y + 8))

            start_text = FONT_SMALL.render(f"Selected start: {start_node} (Click a node to change)", True, DARK_BLUE)
            screen.blit(start_text, (20, HEIGHT - 100))

            key_text = FONT_SMALL.render("Press B for BFS | Press D for DFS | Press ESC to return", True, BLACK)
            screen.blit(key_text, (20, HEIGHT - 75))

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                elif event.type == pygame.MOUSEBUTTONDOWN:
                    mouse_x, mouse_y = event.pos

                    if back_btn.collidepoint(mouse_x, mouse_y):
                        return False
                    elif mst_btn.collidepoint(mouse_x, mouse_y):
                        prim_mst_visualization(screen, clock, start_node)
                        waiting = False
                        return True
                    else:
                        for node, pos in nodes_pos.items():
                            x, y = pos
                            distance = ((mouse_x - x) ** 2 + (mouse_y - y) ** 2) ** 0.5
                            if distance <= 35:
                                start_node = node
                                selected = True
                                waiting = False
                                return True
                elif event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_ESCAPE:
                        return False
                    elif event.key == ord('b') or event.key == ord('B'):
                        if selected:
                            bfs_visualization(screen, clock, start_node)
                            waiting = False
                            return True
                    elif event.key == ord('d') or event.key == ord('D'):
                        if selected:
                            dfs_visualization(screen, clock, start_node)
                            waiting = False
                            return True

            pygame.display.flip()
            clock.tick(30)
        return True

    while True:
        result = wait_for_selection()
        if not result:
            return